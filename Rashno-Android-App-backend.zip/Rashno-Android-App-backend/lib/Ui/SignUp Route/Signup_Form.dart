import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter/material.dart';
import 'package:rashno/Widgets/Buttons/CustomLoadingButton.dart';
import 'package:rashno/Widgets/Text%20Fields/CustomTextField.dart';
import 'package:rashno/ui/MainWrapper.dart';
import 'package:rounded_loading_button/rounded_loading_button.dart';
import 'package:rashno/Widgets/Text%20Fields/PassWordTextField.dart';
import '../../Functions And Providers/Classes/UserClass.dart';
import '../../Functions And Providers/SignUp_Functions/PasswrodValidation.dart';
import '../../Functions And Providers/providers/UserProvider.dart';
import '../../Widgets/PassGuid.dart';
import '../../Widgets/TitleWidget.dart';
import '../../utils/constants/sizes.dart';


class Signup_Form extends ConsumerStatefulWidget {
  static String routName = '/SignUpCompilation';

  @override
  ConsumerState<Signup_Form> createState() => _Signup_FormState();
}

class _Signup_FormState extends ConsumerState<Signup_Form> {
  late TextEditingController _nameController = TextEditingController();
  late TextEditingController _passwordController = TextEditingController();
  late TextEditingController _passwordcheckController = TextEditingController();
  final formKey = GlobalKey<FormState>();
  final RoundedLoadingButtonController _loginOTPbtnController =
      RoundedLoadingButtonController();

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController();
    _passwordController = TextEditingController();
    _passwordcheckController = TextEditingController();
  }

  @override
  void dispose() {
    super.dispose();
    _nameController.dispose();
    _passwordController.dispose();
    _passwordcheckController.dispose();
  }

  // this function checks if the form is valid :
  void _delayLogin(User user) async {
    Timer(Duration(seconds: 1), () {
      if (formKey.currentState!.validate()) {
        _loginOTPbtnController.success();
        user.name = _nameController.text;
        Navigator.pushNamed(context, MainWrapper.routName);
      } else {
        _loginOTPbtnController.error();
      }
    });
  }





late bool _isValid = false;
  late bool _isEight = false ;
 void  ValidChar(String? value) {

    RegExp regex1 = RegExp(r'^(?=.*[0-9])(?=.*[a-z]).{0,32}$');
    if (regex1.hasMatch(value!)) {
      _isValid = true ;
    }
    else {_isValid = false ;}

  }
  void Eight(String value) {
    RegExp regex1 = RegExp(r'^.{8,32}$');
      if (regex1.hasMatch(value)) {
        _isEight = true ;
      }
      else {_isEight = false ;}

  }





  @override
  Widget build(BuildContext context) {
    final user = ref.watch(userProvider);
    String? passCheck;
    return SafeArea(
        child: Scaffold(
            body: SingleChildScrollView(
      child: Center(
        child: Container(
          padding: EdgeInsets.only(top: 40.h, left: 16.w, right: 16.w),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TitleWidget(text: 'تکمیل ثبت نام'),
              SizedBox(
                height: TSizes.xl.h,
              ),
              Form(
                key: formKey,
                child: Column(
                  children: [

                    CustomTextField(

                      limitation: 20,
                      validation: (value) {
                        if (value.isEmpty) {
                          return 'لطفا نام خود را وارد کنید ';
                        }
                      },
                      controller: _nameController,
                      atuoFocused: true,
                      hintText: 'نام',
                      icon: Icon(
                        FontAwesomeIcons.pen,
                        size: 20,
                      ),
                      keyboardType: TextInputType.name,
                    ),


                    SizedBox(
                      height: TSizes.md.h,
                    ),
                    CustomPassWord(
                      onChanged: (value){
                        setState(() {
                          Eight(value) ;
                          ValidChar(value) ;
                        });

                      },
                        limitation: 32,
                        validation: validatePassword,
                        hintText: "رمز عبور",
                        obscureText: true,
                        controller: _passwordController),
                    SizedBox(
                      height: TSizes.md.h,
                    ),
                    CustomPassWord(
                      limitation: 32,
                      controller: _passwordcheckController,
                      validation: (value) {
                        if (value == _passwordController.text) {
                          return null;
                        } else if (value.isEmpty) {
                          return "تکرار رمز را وارد کنید";
                        }
                        return "رمز عبور و تکرار آن برابر نیست";
                      },
                      hintText: "تکرار رمز",
                      obscureText: true,
                    ),

                  ],
                ),
              ),
              SizedBox(
                height: TSizes.md.h,
              ),
              PassGuid( isEight: _isEight , isValidChar: _isValid,),
              SizedBox(
                height: TSizes.xl.h,
              ),
              CustomLoadingButton(
                text: 'تکمیل ثبت نام ',
                Controller: _loginOTPbtnController,
                onPressed: () {
                  setState(() {
                    _delayLogin(user);
                  });
                },
              ),
            ],
          ),
        ),
      ),
    )));
  }
}







