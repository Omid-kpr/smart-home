import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:rashno/Widgets/Text%20Fields/CustomTextField.dart';
import '../../Functions And Providers/SignUp_Functions/IranianPhoneValidation.dart';
import '../../Functions And Providers/providers/phoneNumberProvider.dart';
import '../../Utils/constants/colors.dart';
import '../../Widgets/Buttons/CustomLoadingButton.dart';
import '../../Widgets/TitleWidget.dart';
import '../../utils/constants/sizes.dart';
import '../Login Route/LoginPage.dart';
import 'Signup_Validation.dart';
import 'package:rounded_loading_button/rounded_loading_button.dart';

class Signup_Screen extends ConsumerStatefulWidget {
  static String routName = '/SignUpPage';
  Signup_Screen({
    super.key,
  });

  @override
  Signup_ScreenState createState() => Signup_ScreenState();
}

//---------------------------------------------------------------

class Signup_ScreenState extends ConsumerState<Signup_Screen> {
  late TextEditingController _phoneNumberController;
  final formKey = GlobalKey<FormState>();
  final RoundedLoadingButtonController _loginOTPbtnController =
      RoundedLoadingButtonController();
  late String phone;

  @override
  void initState() {
    super.initState();
    _phoneNumberController = TextEditingController();
  }

  @override
  void dispose() {
    _phoneNumberController.dispose();
    super.dispose();
  }

  // this function checks if the phone number is valid , also adds some delay
  void _delaySendPinCode() async {
    Timer(Duration(seconds: 1), () {
      if (formKey.currentState!.validate()) {
        _loginOTPbtnController.success();
        ref
            .read(PhoneNumberProvider.notifier)
            .update((state) => _phoneNumberController.text);
        phone = ref.watch(PhoneNumberProvider) ?? '';
        Navigator.pushNamed(context, Signup_Validation.routName);
      }
      else {
        _loginOTPbtnController.error();
      }
    });
  }

  //----------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: SingleChildScrollView(
      child: Center(
        child: Container(
          padding: EdgeInsets.only(top: 40.h, left: 16.w, right: 16.w),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TitleWidget(text: 'ثبت نام در رشنو'),
              SizedBox(
                height: TSizes.xl.h,
              ),
              Form(
                key: formKey,
                child: CustomTextField(
                  limitation: 11,
                  validation: validatePhoneNumber,
                  atuoFocused: false,
                  controller: _phoneNumberController,
                  hintText: 'شماره موبایل',
                  keyboardType: TextInputType.phone,
                ),
              ),
              SizedBox(
                height: TSizes.xl.h,
              ),
              CustomLoadingButton(
                text: 'ارسال کد تایید',
                Controller: _loginOTPbtnController,
                onPressed: () {
                  setState(() {
                    _delaySendPinCode();
                  });
                },
              ),
              SizedBox(
                height: TSizes.xl.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextButton(
                    onPressed: () {
                      Navigator.pushNamed(context, Login_Screen.routName);
                    },
                    child: Text(
                      ' وارد شوید',
                      style: Theme.of(context)
                          .textTheme
                          .titleSmall
                          ?.copyWith(color: TColors.primary),
                    ),
                  ),
                  Text(
                    'حساب کاربری دارید؟ ',
                    style: Theme.of(context).textTheme.bodyLarge,
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    )));
  }
}
