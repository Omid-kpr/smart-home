import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pinput/pinput.dart';
import 'package:rashno/Const/styles.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:rounded_loading_button/rounded_loading_button.dart';
import 'package:timer_count_down/timer_count_down.dart';
import '../../Functions And Providers/Classes/UserClass.dart';
import '../../Functions And Providers/providers/UserProvider.dart';
import '../../Functions And Providers/providers/phoneNumberProvider.dart';
import '../../Functions And Providers/providers/themeProvider.dart';
import '../../Widgets/Buttons/CustomLoadingButton.dart';
import '../../Widgets/TitleWidget.dart';
import '../../utils/constants/colors.dart';
import '../../utils/constants/sizes.dart';
import 'Signup_Form.dart';
import 'Signup_Screen.dart';

class Signup_Validation extends ConsumerStatefulWidget {
  static String routName = '/OtpScreen';
  const Signup_Validation({super.key});
  @override
  ConsumerState<Signup_Validation> createState() =>
      _Signup_OTP_ValidationState();
}

class _Signup_OTP_ValidationState extends ConsumerState<Signup_Validation> {
  final RoundedLoadingButtonController _loginOTPbtnController =
      RoundedLoadingButtonController();
  final formKey = GlobalKey<FormState>();
  Color _resendColor =  TColors.error  ;
  bool _resendCode = false;
  late String _pinCode;
  @override
  void initState() {
    _resendCode = false;
    _pinCode = '';
  }

  // this function checks if the entered pinCode is valid  :
  void _delayCodeValidation(String pin, User user, String phone) async {
      Timer(Duration(seconds: 1), () {
        if (formKey.currentState!.validate()) {

        user.phone = phone;
        Navigator.pushNamed(context, Signup_Form.routName);}

        else {
          _loginOTPbtnController.error();
          _loginOTPbtnController.reset() ;
        }

      });

  }

//----------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(userProvider);
    final String phone = ref.read(PhoneNumberProvider) ?? '';
    final defaultPinTheme = PinTheme(
      width: 56,
      height: 56,
      textStyle: Theme.of(context)
          .textTheme
          .headlineSmall
          ?.copyWith(color: Colors.white),
      decoration: BoxDecoration(
        border: Border.all(color: TColors.primary),
        borderRadius: BorderRadius.circular(8),
      ),
    );
    final focusedPinTheme = defaultPinTheme.copyDecorationWith(
      border: Border.all(color: TColors.primary),
      color: Colors.black12,
      borderRadius: BorderRadius.circular(15),
    );

    final submittedPinTheme = defaultPinTheme.copyWith(
      decoration: defaultPinTheme.decoration?.copyWith(
        color: kAccentColor,
      ),
    );
    // end of customizations for Pin_out widget
final _isLight = ref.watch(appThemeStateNotifier) ;

    return SafeArea(
        child: Scaffold(
      body: SingleChildScrollView(
        child: Center(
          child: Container(
            padding: EdgeInsets.only(top: 40.h, left: 16.w, right: 16.w),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                TitleWidget(text: 'تایید شماره'),
                SizedBox(
                  height: TSizes.xl.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('کد تایید به ${phone} ارسال شد',
                        style: Theme.of(context).textTheme.titleSmall),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Countdown(
                        seconds: 60,
                        build: (BuildContext context, double time) => Text(
                              time.toString(),
                              style: Theme.of(context).textTheme.titleSmall,
                            ),
                        interval: Duration(seconds: 1),
                        onFinished: () {
                          setState(() {
                            _resendCode = true;
                            _resendColor = TColors.success;
                          });

                        }),
                    TextButton(
                        onPressed: () {
                          if (_resendCode) {

                          }
                        },
                        child: Text(
                          'ارسال مجدد کد تایید ',
                          style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: _resendColor),
                        ))
                  ],
                ),
                SizedBox(
                  height: TSizes.xl.h,
                ),
                Form(
                  key: formKey,
                  child: Container(
                    child: Pinput(
                      key: widget.key,
                      keyboardType: TextInputType.number,
                      length: 4,
                      autofocus: true,
                      defaultPinTheme: defaultPinTheme,
                      focusedPinTheme: focusedPinTheme,
                      submittedPinTheme: submittedPinTheme,
                      validator: (value) =>
                          value == '2222' ? null : "کد تایید اشتباه است",
                      closeKeyboardWhenCompleted: true,
                      isCursorAnimationEnabled: true,
                      pinputAutovalidateMode: PinputAutovalidateMode.onSubmit,
                      androidSmsAutofillMethod:
                          AndroidSmsAutofillMethod.smsRetrieverApi,
                      showCursor: true,
onChanged: (pin) =>{_pinCode = pin},
                      onCompleted: (pin) => {
                        setState(() {
                          _delayCodeValidation(pin, user, phone);


                        })
                      },
                    ),
                  ),
                ),
                SizedBox(
                  height: TSizes.xl.h,
                ),
                CustomLoadingButton(
                  text: 'تایید شماره',
                  Controller: _loginOTPbtnController,
                  onPressed: () {
                    setState(() {

                        _delayCodeValidation(_pinCode, user, phone);


                    });
                  },
                ),
                SizedBox(
                  height: TSizes.md.h,
                ),
                TextButton(
                  onPressed: () {
                    Navigator.pushNamed(context, Signup_Screen.routName);
                    //Navigator.pop(context);
                  },
                  child: Text('تغییر شماره ',
                      style: Theme.of(context).textTheme.titleSmall),
                ),
              ],
            ),
          ),
        ),
      ),
    ));
  }
}
