import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter/material.dart';
import 'package:rashno/Const/styles.dart';
import '../../Widgets/Animation/FadeAnimation.dart';
import '../../Widgets/ContactSheet.dart';
import '../../Widgets/ThemeSwitcher.dart';
import '../../Widgets/TitleWidget.dart';
import '../../utils/constants/colors.dart';
import '../../utils/constants/sizes.dart';
import '../Login Route/LoginPage.dart';
import '../SignUp Route/Signup_Screen.dart';

class StartScreen extends ConsumerStatefulWidget {
  static String routName = '/StartScreen';

  @override
  ConsumerState<StartScreen> createState() => _StartScreenState();
}

class _StartScreenState extends ConsumerState<StartScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          child: Center(
            child: Container(
              padding: EdgeInsets.only(top: 10.h, left: 16.w, right: 16.w),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                          onPressed: () {
                            ContactSheet(context);
                          },
                          icon: Icon(
                            FontAwesomeIcons.phone,
                            size: 20,
                          )),
                      ThemeSwitcher()
                    ],
                  ),
                  Column(
                    children: [
                      SizedBox(
                        height: TSizes.md.h,
                      ),
                      FadeInAnimation(
                        delay: 1,
                        child: Card(
                            color: TColors.primary,
                          elevation: 10,
                          child: Container(
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(24)),
                            padding: EdgeInsets.symmetric(horizontal: 20),

                            child: Image(
                              height: 160.h,
                              width: MediaQuery.of(context).size.width,
                              image: AssetImage(
                                'assets/LightLogo.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 40.h,
                      ),
                      FadeInAnimation(
                        delay: 1.5,
                        child: Container(
                          child: Column(
                            children: [
                              FadeInAnimation(
                                delay: 1.5,
                                child: TitleWidget(text: 'خانه هوشمند رشنو'),
                              ),

                              FadeInAnimation(
                                delay: 1.8,
                                child: Text('کنترل خانه هوشمند' , style: Theme.of(context).textTheme.bodyMedium,),
                              ),

                              SizedBox(
                                width: TSizes.xxl.w,
                              ),
                              Column(
                                children: [
                                  FadeInAnimation(
                                    delay: 2,
                                    child: Container(
                                      width: double.infinity,
                                      margin: EdgeInsets.only(
                                          top: 30,
                                          bottom: 30,
                                          left: 10,
                                          right: 10),
                                      child: Column(
                                        children: [
                                          Row(
                                            children: [
                                              Expanded(
                                                  flex: 1,
                                                  child: FadeInAnimation(
                                                    delay: 2,
                                                    child: OutlinedButton(
                                                      child: Text("ثبت نام"),
                                                      onPressed: () {
                                                        Navigator.pushNamed(
                                                            context,
                                                            Signup_Screen
                                                                .routName);
                                                      },
                                                    ),
                                                  )),
                                              SizedBox(
                                                width: kSize_15.w,
                                              ),
                                              Expanded(
                                                  flex: 1,
                                                  child: FadeInAnimation(
                                                    delay: 1.5,
                                                    child: ElevatedButton(
                                                        child: Text('ورود'),
                                                        onPressed: () {
                                                          Navigator.pushNamed(
                                                              context,
                                                              Login_Screen
                                                                  .routName);
                                                        }),
                                                  )),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
