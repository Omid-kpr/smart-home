import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pinput/pinput.dart';
import 'package:rashno/Const/styles.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:rounded_loading_button/rounded_loading_button.dart';
import 'package:timer_count_down/timer_count_down.dart';
import '../../Functions And Providers/providers/phoneNumberProvider.dart';
import '../../Functions And Providers/providers/themeProvider.dart';
import '../../Widgets/Buttons/CustomLoadingButton.dart';
import '../../Widgets/OTP Widget/OtpWidget.dart';
import '../../Widgets/TitleWidget.dart';
import '../../utils/constants/colors.dart';
import '../../utils/constants/sizes.dart';
import '../MainWrapper.dart';

class Login_Otp_Validation extends ConsumerStatefulWidget {
  Login_Otp_Validation({super.key});

  static String routName = '/LoginWithOtpScreen';

  @override
  LoginWithOtpScreenState createState() => LoginWithOtpScreenState();
}

class LoginWithOtpScreenState extends ConsumerState<Login_Otp_Validation> {
  final formKey = GlobalKey<FormState>();
  Color _resendColor =  TColors.error  ;
  bool _resendCode = false;


  final RoundedLoadingButtonController _loginOTPbtnController =
  RoundedLoadingButtonController();





  // this function checks if the entered pinCode is valid  :
  void _delayCodeValidation(String pin ) async {
    Timer(Duration(seconds: 1), () {
      if ( pin == '2222') {
        _loginOTPbtnController.success();
        _loginOTPbtnController.reset() ;

        Navigator.pushNamed(context, MainWrapper.routName);}

      else {
        _loginOTPbtnController.error();
        _loginOTPbtnController.reset() ;

      }

    });

  }

//----------------------------------------------------------------













  @override
  Widget build(BuildContext context) {

    final String phone = ref.read( PhoneNumberProvider)?? '';



    late String pinCode;
    final defaultPinTheme = PinTheme(
      width: 56,
      height: 56,
      textStyle: Theme.of(context)
          .textTheme
          .headlineSmall
          ?.copyWith(color: Colors.white),
      decoration: BoxDecoration(
        border: Border.all(color: TColors.primary),
        borderRadius: BorderRadius.circular(8),
      ),
    );
    final focusedPinTheme = defaultPinTheme.copyDecorationWith(
      border: Border.all(color: TColors.primary),
      color: Colors.black12,
      borderRadius: BorderRadius.circular(15),
    );

    final submittedPinTheme = defaultPinTheme.copyWith(
      decoration: defaultPinTheme.decoration?.copyWith(
        color: kAccentColor,
      ),
    );
    // end of customizations for Pin_out widget

    final _isLight = ref.watch(appThemeStateNotifier) ;

    return SafeArea(
        child: Scaffold(

      body: SingleChildScrollView(
        child: Center(
          child: Container(
            padding: EdgeInsets.only(top: 40.h, left: 16.w, right: 16.w),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                TitleWidget(text: 'تایید شماره'),
                SizedBox(
                  height: TSizes.xl.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('کد تایید به ${phone} ارسال شد',
                        style: Theme.of(context).textTheme.titleSmall),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Countdown(
                        seconds: 60,
                        build: (BuildContext context, double time) => Text(
                          time.toString(),
                          style: Theme.of(context).textTheme.titleSmall,
                        ),
                        interval: Duration(seconds: 1),
                        onFinished: () {
                          setState(() {
                            _resendCode = true;
                            _resendColor = TColors.success;
                          });

                        }),
                    TextButton(
                        onPressed: () {
                          if (_resendCode) {

                          }
                        },
                        child: Text(
                          'ارسال مجدد کد تایید ',
                          style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: _resendColor),
                        ))
                  ],
                ),
                SizedBox(
                  height: TSizes.xl.h,
                ),
                Form(
                  key: formKey,
                  child: Container(
                    child: Pinput(
                      key: widget.key,
                      keyboardType: TextInputType.number,
                      length: 4,
                      autofocus: true,
                      defaultPinTheme: defaultPinTheme,
                      focusedPinTheme: focusedPinTheme,
                      submittedPinTheme: submittedPinTheme,
                      validator: (value) =>
                      value == '2222' ? null : "کد تایید اشتباه",
                      closeKeyboardWhenCompleted: true,
                      isCursorAnimationEnabled: true,
                      pinputAutovalidateMode: PinputAutovalidateMode.onSubmit,
                      androidSmsAutofillMethod:
                      AndroidSmsAutofillMethod.smsRetrieverApi,
                      showCursor: true,
                      onCompleted: (pin) => {
                        setState(() {
                          _delayCodeValidation(pin);
                          pinCode = pin;
                        })
                      },
                    ),
                  ),
                ),
                SizedBox(
                  height: TSizes.xl.h,
                ),
                CustomLoadingButton( text: 'ورود' ,Controller: _loginOTPbtnController, onPressed: (){
                  setState(() {
                    if (formKey.currentState!.validate()) {
                      _delayCodeValidation(pinCode );
                    }
                  });
                } ,),
                SizedBox(
                  height: TSizes.md.h,
                ),
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text('تغییر شماره ',   style: Theme.of(context).textTheme.titleSmall),
                ),
              ],
            ),
          ),
        ),
      ),
    ));
  }
}
