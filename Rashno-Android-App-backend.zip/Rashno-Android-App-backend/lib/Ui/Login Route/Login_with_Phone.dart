import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:rashno/Widgets/Text%20Fields/CustomTextField.dart';
import 'package:rounded_loading_button/rounded_loading_button.dart';
import '../../Functions And Providers/SignUp_Functions/IranianPhoneValidation.dart';
import '../../Functions And Providers/providers/phoneNumberProvider.dart';
import '../../Widgets/Buttons/CustomLoadingButton.dart';
import '../../Widgets/TitleWidget.dart';
import '../../utils/constants/colors.dart';
import '../../utils/constants/sizes.dart';
import 'Login_Validation.dart';

class LoginWithPhone extends ConsumerStatefulWidget {
  static String routName = '/LoginWithPhone';

  LoginWithPhone({
    super.key,
  });

  @override
  LoginWithPhoneState createState() => LoginWithPhoneState();
}

class LoginWithPhoneState extends ConsumerState<LoginWithPhone> {
  late TextEditingController _phoneNumberController;
  final formKey = GlobalKey<FormState>();
  final RoundedLoadingButtonController _loginOTPbtnController =
      RoundedLoadingButtonController();

  @override
  void initState() {
    super.initState();
    _phoneNumberController = TextEditingController();
  }

  @override
  void dispose() {
    _phoneNumberController.dispose();
    super.dispose();
  }

  void _delayStartPhoneValidation() async {
    if (formKey.currentState!.validate()) {
      Timer(Duration(seconds: 1), () {

        _loginOTPbtnController.success();
        Navigator.pushNamed(context, Login_Otp_Validation.routName);
      });
    } else {
      _loginOTPbtnController.error();
    }
  }

  @override
  Widget build(BuildContext context) {


    return SafeArea(
        child: Scaffold(
         
            body: SingleChildScrollView(
              child: Center(
                child: Container(
                  padding: EdgeInsets.only(top: 40.h, left: 16.w, right: 16.w),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Column(
                        children: [
                          TitleWidget(text: 'ورود با رمز یکبار مصرف'),
                          SizedBox(
                            height: TSizes.xl.h,
                          ),
                          Column(
                            children: [
                              Form(
                                key: formKey,
                                child: CustomTextField(
                                  limitation: 11,
                                  validation: validatePhoneNumber,
                                  atuoFocused: true,
                                  controller: _phoneNumberController,
                                  hintText: 'شماره موبایل',
                                  icon: Icon(
                                    FontAwesomeIcons.phone,
                                    size: 20,
                                  ),
                                  keyboardType: TextInputType.phone,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: TSizes.xl.h,
                          ),
                          CustomLoadingButton(
                            text: 'تایید شماره',
                            Controller: _loginOTPbtnController,
                            onPressed: () {
                              setState(() {
                                ref.watch(PhoneNumberProvider.notifier).update((state) => _phoneNumberController.text) ;
                              _delayStartPhoneValidation();
                              });
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            )));
  }
}
