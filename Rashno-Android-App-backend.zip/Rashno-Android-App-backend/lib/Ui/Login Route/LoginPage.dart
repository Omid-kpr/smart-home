import 'dart:async';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter/material.dart';
import 'package:rashno/Widgets/Text%20Fields/CustomTextField.dart';
import 'package:rounded_loading_button/rounded_loading_button.dart';
import 'package:rashno/Widgets/Text%20Fields/PassWordTextField.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../Functions And Providers/SignUp_Functions/IranianPhoneValidation.dart';
import '../../Functions And Providers/SignUp_Functions/PasswrodValidation.dart';
import '../../ServerFunction/validation Functions.dart';
import '../../Widgets/Buttons/CustomLoadingButton.dart';
import '../../utils/constants/sizes.dart';
import '../MainWrapper.dart';
import '../SignUp Route/Signup_Screen.dart';
import 'Login_with_Phone.dart';
import 'package:rashno/Widgets/TitleWidget.dart';

class Login_Screen extends StatefulWidget {
  static String routName = '/LoginPage_OTP';

  @override
  State<Login_Screen> createState() => _Login_ScreenState();
}

class _Login_ScreenState extends State<Login_Screen> {
  late TextEditingController _phoneNumberController = TextEditingController();
  late TextEditingController _passWordController = TextEditingController();
  final formKey = GlobalKey<FormState>();
  final RoundedLoadingButtonController _loginOTPbtnController = RoundedLoadingButtonController();

  @override
  void initState() {
    super.initState();
    _phoneNumberController = TextEditingController();
    _passWordController  = TextEditingController();
  }

  @override
  void dispose() {
    super.dispose();
    _phoneNumberController.dispose();
    _passWordController.dispose();
  }

  void _delayLogin() async {
    if (formKey.currentState!.validate()) {
      Timer(Duration(seconds: 1), () async {
        await login(_phoneNumberController.text, _passWordController.text);
        while (message_handeled == false) {
          print("waiting for token");
          await Future.delayed(Duration(seconds: 1));
        }
        SharedPreferences prefs =
        await SharedPreferences.getInstance();
        String? token = await prefs.getString("token");
        if (token == null || token == "null") {
          print("failed to login");
          _loginOTPbtnController.error();
        } else {
          Navigator.pushNamed(context, MainWrapper.routName );
          _loginOTPbtnController.success();
        }


        // Navigator.pushNamed(context, MainWrapper.routName );
      });
    } else {
      _loginOTPbtnController.error();
    }
  }









  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(

            body: SingleChildScrollView(
              child: Center(
                child: Container(
                  padding: EdgeInsets.only(top: 40.h, left: 16.w, right: 16.w),

                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      TitleWidget(text: 'ورود به حساب کاربری'),
                      SizedBox(
                        height: TSizes.xl.h,
                      ),
                      Form(
                        key: formKey,
                        child: Column(
                          children: [
                            CustomTextField(
                              limitation: 11,
                              validation: validatePhoneNumber,
                              controller: _phoneNumberController,
                              atuoFocused: false,
                              hintText: 'شماره موبایل',
                              icon: Icon(
                                FontAwesomeIcons.phone,
                                size: 20,
                              ),
                              keyboardType: TextInputType.phone,
                            ),
                            SizedBox(
                              height: TSizes.md.h,
                            ),
                            CustomPassWord(
                                limitation: 32,
                                validation: validatePassword,
                                hintText: "رمز عبور",
                                obscureText: true,
                                controller: _passWordController),

                            //CustomTextField(hintText: 'رمز' ,obscureText: true ) ,
                            SizedBox(
                              height: TSizes.xl.h,
                            ),
                          ],
                        ),
                      ),
                      CustomLoadingButton(
                        text: 'ورود',
                        Controller: _loginOTPbtnController,
                        onPressed: () {
                          setState(() {
                            if (formKey.currentState!.validate()) {
                              _delayLogin();
                            } else {
                              _loginOTPbtnController.error();
                            }
                          });
                        },
                      ),
                      SizedBox(
                        height: TSizes.xl.h,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          OutlinedButton(
                            onPressed: () {
                              Navigator.pushNamed(
                                  context, LoginWithPhone.routName);
                            },
                            child: Text('ورود با رمز یک بار مصرف',
                                style: Theme.of(context).textTheme.titleSmall),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: TSizes.sm.h,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TextButton(
                            onPressed: () {
                              Navigator.pushNamed(
                                  context, Signup_Screen.routName);
                            },
                            child: Text(
                              'ایجاد حساب کاربری',
                              style: Theme.of(context).textTheme.bodyMedium,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            )));
  }
}
