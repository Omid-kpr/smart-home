import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:rashno/Functions%20And%20Providers/providers/themeProvider.dart';
import '../../Functions And Providers/providers/RoomListProvider.dart';
import 'HomePageFunctions/CategoryShow.dart';


class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});
  static String routName = '/UserHomePage';
  @override
  ConsumerState<HomePage> createState() => _UserHomePageState();
}

class _UserHomePageState extends ConsumerState<HomePage> {

  @override
  Widget build(BuildContext context) {
    // final _roomList = ref.watch(RoomListProvider);
    // bool _isLight = ref.watch(appThemeStateNotifier);
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title:
          Text('مدیریت خانه', style: Theme.of(context).textTheme.headlineSmall),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          child: Container(

            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [

                  ],
                ),

                CategoryShow() ,



              ],
            ),
          ),
        ),
      ),
    );
  }
}
