import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:rashno/Widgets/TitleWidget.dart';
import 'package:rashno/ui/StartScreens/StartScreen.dart';
import 'package:rashno/utils/constants/sizes.dart';
import '../../Functions And Providers/providers/UserProvider.dart';
import '../../Functions And Providers/providers/themeProvider.dart';
import '../../Widgets/Animation/FadeAnimation.dart';
import '../../Widgets/ContactSheet.dart';
import '../../utils/constants/colors.dart';
import 'HomePageFunctions/AccountEditing.dart';

class UserAccount extends ConsumerStatefulWidget {
  const UserAccount({super.key});
  static String routName = '/UserAccount';

  @override
  ConsumerState<UserAccount> createState() => _UserAccountState();
}

class _UserAccountState extends ConsumerState<UserAccount> {
  @override
  Widget build(BuildContext context) {
    final user = ref.watch(userProvider);
    bool _isLight = ref.watch(appThemeStateNotifier);

    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
          automaticallyImplyLeading: false ,
        title: Text('حساب کاربری',
            style: Theme.of(context).textTheme.headlineSmall),
        centerTitle: true,
      ),
      body: Container(
        color: _isLight ? TColors.primaryLight : TColors.DarkScaffoldBack,
        width: double.infinity,
        child: Column(
          children: [
            SizedBox(
              height: TSizes.xl.h,
            ),
            FadeInAnimation(
              delay: 1,
              child: Image(image: AssetImage( 'assets/Account.png'  ), height: 100 , width: 100,)
            ),
            SizedBox(
              height: TSizes.md.h,
            ),
            FadeInAnimation(delay: 1.1,
            child: TitleWidget(text: user.name)),
        SizedBox(
          height: TSizes.sm,
        ),
            FadeInAnimation(delay: 1.2 , child: Text(  user.phone , style:Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 18) ,)) ,
            SizedBox(
              height: TSizes.md,
            ),

            Expanded(
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 30.w),
                decoration: BoxDecoration(
                    color: _isLight ? TColors.white : TColors.DarkerScaffoldBack ,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20))),
                child: Column(

                  children: [
                    SizedBox(
                      height: TSizes.xxl
                      ,
                    ),
                    AccountEditing(),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 16.0  , horizontal: 20),
                      child: Divider(),
                    ) ,
                    InkWell(
                      hoverColor: TColors.primaryLight,
                      highlightColor:TColors.primaryLight ,
                      onTap: (){
                        ContactSheet(context);
                      },
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 20 ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Icon(FontAwesomeIcons.phone,size: 18,) ,
                            Text('ارتباط با ما' , style: Theme.of(context).textTheme.titleMedium,)

                          ],),
                      ),
                    ) ,
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 16.0  , horizontal: 20),
                      child: Divider(),
                    ) ,
                    InkWell(
                      hoverColor: TColors.primaryLight,
                      highlightColor:TColors.primaryLight ,
                      onTap: (){
                        Navigator.pushNamed(
                            context, StartScreen.routName);
                      },
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 20 ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Icon(FontAwesomeIcons.powerOff , size: 18 ,) ,
                            Text('خروج از حساب کاربری' , style: Theme.of(context).textTheme.titleMedium,)

                          ],),
                      ),
                    ) ,
                  



                  ],
                ),
              ),
            )
          ],
        ),
      ),
    ));
  }
}
