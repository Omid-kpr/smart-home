import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../Functions And Providers/providers/RoomListProvider.dart';
import '../../Utils/constants/colors.dart';
import '../../Utils/constants/sizes.dart';
import '../../Widgets/Item Builder/DeviceBoxBuilder.dart';

class Rooms extends ConsumerStatefulWidget {
  const Rooms({super.key});

  @override
  ConsumerState<Rooms> createState() => _RoomsState();
}

class _RoomsState extends ConsumerState<Rooms> {
  int _CurrentRoom = 0;
  TextEditingController _NewRoomNameController = TextEditingController();

  @override
  void dispose() {
    super.dispose();
    _NewRoomNameController.dispose();
  }

  @override
  void initState() {
    super.initState();
    _NewRoomNameController = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    final _roomList = ref.watch(RoomListProvider);
    // bool _isLight = ref.watch(appThemeStateNotifier);

    return SafeArea(
        child: Scaffold(
          appBar: AppBar(
            automaticallyImplyLeading: false,
            title:
            Text('اتاق ها', style: Theme.of(context).textTheme.headlineSmall),
            centerTitle: true,
          ),
      body: SingleChildScrollView(
        child: Column(
          children: [

            Directionality(
              textDirection: TextDirection.rtl,
              child: SizedBox(
                height: 50.h,
                width: MediaQuery.of(context).size.width,
                child: ListView.builder(
                    physics: BouncingScrollPhysics(),
                    itemCount: _roomList.length,
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (context, index) {
                      return GestureDetector(
                        onTap: () {
                          setState(() {

                            _CurrentRoom = index;
                          });
                        },
                        child: AnimatedContainer(
                          duration: Duration(milliseconds: 200),
                          margin: EdgeInsets.all(4),
                          padding: EdgeInsets.symmetric(
                              horizontal: _CurrentRoom == index ? 22 : 20,
                              vertical: 10),
                          height: 40.h,
                          decoration: BoxDecoration(
                            border: Border.all(
                                width: _CurrentRoom == index ? 1.5 : 1,
                                color:
                                    _CurrentRoom == index
                                        ? TColors.primary
                                        : TColors.primarydark),
                            borderRadius: BorderRadius.circular(
                                _CurrentRoom == index ? 30 : 12),
                          ),
                          child: Center(
                            child: Text(_roomList[index].name,
                                style: Theme.of(context).textTheme.bodyLarge),
                          ),
                        ),
                      );
                    }),
              ),
            ),
        SizedBox(height: TSizes.md,) ,
            DeviceBoxBuilder(CurrentRoom: _CurrentRoom, roomList: _roomList),
          ],
        ),
      ),
    ));
  }
}
