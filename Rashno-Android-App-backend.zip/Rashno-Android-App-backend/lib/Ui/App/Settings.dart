import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_switch/flutter_switch.dart';
import '../../Functions And Providers/Classes/RoomAndDevice.dart';
import '../../Functions And Providers/providers/RoomListProvider.dart';
import '../../Functions And Providers/providers/UserProvider.dart';
import '../../Functions And Providers/providers/themeProvider.dart';
import '../../Widgets/Animation/FadeAnimation.dart';
import '../../Widgets/Buttons/AddNewButton.dart';
import '../../Widgets/ContactSheet.dart';
import '../../Widgets/Text Fields/CustomTextField.dart';
import '../../Widgets/TitleWidget.dart';
import '../../utils/constants/colors.dart';
import '../../utils/constants/sizes.dart';
import '../StartScreens/StartScreen.dart';
import 'HomePageFunctions/AddDevicePage.dart';
import 'HomePageFunctions/CreateNewRoom.dart';

class Settings extends ConsumerStatefulWidget {
  const Settings({super.key});

  @override
  ConsumerState<Settings> createState() => _SettingsState();
}

class _SettingsState extends ConsumerState<Settings> {
  TextEditingController _NewUserNameController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final _roomList = ref.watch(RoomListProvider);
    void _addRoom(String roomName) {
      setState(() {
        Room newRoom = Room(name: roomName);
        _roomList.add(newRoom);
      });
    }

    bool _isLight = ref.watch(appThemeStateNotifier);
    final user = ref.watch(userProvider);
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title:
            Text('تنظیمات', style: Theme.of(context).textTheme.headlineSmall),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Center(
            child: Container(
          width: double.infinity,
          padding: EdgeInsets.only(left: 16.w, right: 16.w),
          child: Column(
            children: [

              FadeInAnimation(
                  delay: 1,
                  child: Image(
                    image: AssetImage('assets/Account.png'),
                    height: 100,
                    width: 100,
                  )),
              SizedBox(
                height: TSizes.md.h,
              ),
              FadeInAnimation(
                  delay: 1.1,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      TitleWidget(text: user.name),

                      IconButton(
                        onPressed: () {
                          showModalBottomSheet<void>(
                            isScrollControlled: true,
                            context: context,
                            builder: (BuildContext context) {
                              return Container(
                                height:
                                    MediaQuery.of(context).size.height * 2 / 3,
                                width: MediaQuery.of(context).size.width,
                                padding: EdgeInsets.all(16.0),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    TitleWidget(text: "ویرایش اطلاعات"),
                                    SizedBox(
                                      height: TSizes.xl.h,
                                    ),
                                    Text(
                                      'اطلاعات حساب کاربری را ویرایش کنید',
                                      style:
                                          Theme.of(context).textTheme.bodyLarge,
                                    ),
                                    SizedBox(
                                      height: TSizes.md.h,
                                    ),
                                    CustomTextField(
                                        validation: (value) {
                                          if (value.isEmpty) {
                                            return 'لطفا نام خود را وارد کنید ';
                                          }
                                        },
                                        hintText: 'نام جدید ',
                                        controller: _NewUserNameController,
                                        atuoFocused: false,
                                        limitation: 20),
                                    SizedBox(
                                      height: TSizes.sm.h,
                                    ),
                                    SizedBox(
                                      height: TSizes.md.h,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Expanded(
                                          flex: 1,
                                          child: OutlinedButton(
                                            onPressed: () {
                                              Navigator.of(context)
                                                  .pop(); // Close the bottom sheet
                                            },
                                            child: Text(
                                              'بستن',
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .titleSmall,
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          width: TSizes.sm.w,
                                        ),
                                        Expanded(
                                          flex: 3,
                                          child: ElevatedButton(
                                            onPressed: () {
                                              ref
                                                  .read(userProvider.notifier)
                                                  .updateName(
                                                      _NewUserNameController
                                                          .text
                                                          .toString());
                                              Navigator.pop(context);
                                            },
                                            child: Text(
                                              'ذخیره',
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .titleSmall
                                                  ?.copyWith(
                                                      color: Colors.white),
                                            ),
                                          ),
                                        ),
                                      ],
                                    )
                                  ],
                                ),
                              );
                            },
                          );
                        },
                        icon: Icon(
                          Icons.edit,
                          size: 20,
                        ),
                      ),
                    ],
                  )),
              SizedBox(
                height: TSizes.xs,
              ),
              FadeInAnimation(
                  delay: 1.2,
                  child: Text(
                    user.phone,
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(fontSize: 18),
                  )),
              SizedBox(
                height: TSizes.md,
              ),
              AddNewButton(
                  text: 'اضافه کردن دستگاه هوشمند',
                  icon: Icons.lightbulb,
                  onTab: () {
                    Navigator.pushNamed(context, AddDevicePage.routName);
                  }),
              SizedBox(
                height: TSizes.sm.h,
              ),
              AddNewButton(
                  text: 'مدیریت اتاق های خانه',
                  icon: Icons.window,
                  onTab: () {
                    setState(() {
                      NewRoomModalBottomSheet(context, _roomList, _addRoom);
                    });
                  }),
              SizedBox(
                height: TSizes.sm.h,
              ),
              AddNewButton(
                  text: 'ساخت سناریو جدید',
                  icon: Icons.timer,
                  onTab: () {
                    Navigator.pushNamed(context, AddDevicePage.routName);
                  }),
              SizedBox(
                height: TSizes.sm.h,
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                height: 70.h,
                decoration: BoxDecoration(
                    color: _isLight
                        ? TColors.primaryLight
                        : TColors.Offcolor,
                    borderRadius: BorderRadius.circular(30)),
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text('تنظیم روشنایی صفحه'),
                      FlutterSwitch(
                        inactiveIcon:
                            Icon(Icons.nightlight_round, color: TColors.dark),
                        activeIcon: Icon(
                          Icons.sunny,
                          color: TColors.dark,
                        ),
                        activeColor: TColors.accent,
                        inactiveColor: TColors.darkContainer,
                        activeText: 'تاریک',
                        activeTextColor: Colors.white,
                        inactiveTextColor: Colors.white,
                        duration: Duration(milliseconds: 300),
                        inactiveText: 'روشن',
                        width: 110.0,
                        height: 40.0,
                        valueFontSize: 14.0,
                        toggleSize: 40.0,
                        value: _isLight,
                        borderRadius: 40.0,
                        padding: 8.0,
                        showOnOff: true,
                        onToggle: (val) {
                          setState(() {
                            val = ref
                                .read(appThemeStateNotifier.notifier)
                                .state = !_isLight;
                            // Vibration.vibrate(amplitude: 128);
                          });
                        },
                      ),
                    ],
                  ),
                ),
              ),
           SizedBox(height: TSizes.xs,),
           Divider() ,
              SizedBox(height: TSizes.xs,),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () { Navigator.pushNamed(
                          context, StartScreen.routName);},
                      child: Container(
                        child: Center(child: Text('خروج'),),
                        decoration: BoxDecoration(
                            color: _isLight ? TColors.primaryLight : TColors.Offcolor ,
                            borderRadius: BorderRadius.circular(30)),

                        height: 70.h,
                      ),
                    ),
                  ),
SizedBox(width: 8,) ,
                  Expanded(
                    child: GestureDetector(
                      onTap: () {  ContactSheet(context);},
                      child: Container(
                        child: Center(child: Text('ارتباط با ما  '),),
                        decoration: BoxDecoration(
                            color: _isLight ? TColors.primaryLight : TColors.Offcolor ,
                            borderRadius: BorderRadius.circular(30)),

                        height: 70.h,
                      ),
                    ),
                  ),

                ],
              )
            ],
          ),
        )),
      ),
    ));
  }
}
