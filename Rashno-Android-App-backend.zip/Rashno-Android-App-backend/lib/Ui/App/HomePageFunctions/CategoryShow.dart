import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:zoom_tap_animation/zoom_tap_animation.dart';
import '../../../Const/styles.dart';
import '../../../Functions And Providers/providers/RoomListProvider.dart';
import '../../../Functions And Providers/providers/themeProvider.dart';
import '../../../Utils/constants/colors.dart';
import '../../../Utils/constants/sizes.dart';


class CategoryShow extends ConsumerStatefulWidget {
  const CategoryShow({super.key});

  @override
  ConsumerState<CategoryShow> createState() => _CategoryShowState();
}

class _CategoryShowState extends ConsumerState<CategoryShow> {
  @override
  Widget build(BuildContext context) {
    final _roomList = ref.watch(RoomListProvider);
    int ShowRoom = 0;
    bool _isLight = ref.watch(appThemeStateNotifier);
    return Container(
      padding: EdgeInsets.only( left: 8.w, right: 8.w),
      child: Column(
        children: [
          Container(
              height: 600.h,
              width: double.infinity,
              child: ListView.separated(
                  physics: ScrollPhysics(),
                  separatorBuilder: (BuildContext context, int index) =>
                      SizedBox(
                        height: TSizes.sm.h,
                      ),
                  itemCount: _roomList.length,
                  shrinkWrap: true,
                  itemBuilder: (BuildContext context, int index) {
                    ShowRoom = index;
                    if (_roomList[ShowRoom].devices.isNotEmpty) {

                      return Container(
                        decoration: BoxDecoration(
                            color: _isLight ? TColors.primaryLight : TColors.Offcolor,
                            borderRadius: BorderRadius.circular(16)),
                        padding: EdgeInsets.all(10.h),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Padding(
                              padding:
                              const EdgeInsets.symmetric(vertical: 8.0),
                              child: Text(
                                _roomList[index].name,
                                style: Theme.of(context).textTheme.titleMedium,
                              ),
                            ),
                            SizedBox(
                              height: TSizes.sm.h,
                            ),
                            Directionality(
                              textDirection: TextDirection.rtl,
                              child: Container(
                                height: 55.h,
                                width: MediaQuery.of(context).size.width,
                                child: ListView.builder(
                                    physics: BouncingScrollPhysics(),
                                    scrollDirection: Axis.horizontal,
                                    itemCount: _roomList[index].devices.length,
                                    itemBuilder: (context, index2) {
                                      return ZoomTapAnimation(
                                        child: Directionality(
                                          textDirection: TextDirection.rtl,
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                left: TSizes.sm),
                                            child: GestureDetector(
                                              onTap: () {
                                                setState(() {
                                                  _roomList[index]
                                                      .devices[index2]
                                                      .onOff =
                                                  !_roomList[index]
                                                      .devices[index2]
                                                      .onOff;
                                                });
                                              },
                                              child: ConstrainedBox(
                                                constraints: BoxConstraints(
                                                    minWidth: 90.w),
                                                child: Container(
                                                    padding:
                                                    EdgeInsets.symmetric(
                                                        horizontal: 12),
                                                    decoration: BoxDecoration(
                                                      color: _roomList[index]
                                                          .devices[index2]
                                                          .onOff
                                                          ? kOnColor
                                                          : kOffColor,
                                                      borderRadius:
                                                      BorderRadius.circular(
                                                          20),
                                                    ),
                                                    child: Row(
                                                      mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceEvenly,
                                                      children: [
                                                        Icon(
                                                          _roomList[index]
                                                              .devices[index2]
                                                              .icon,
                                                          color: Colors.white,
                                                        ),
                                                        Text(
                                                          _roomList[index]
                                                              .devices[index2]
                                                              .name,
                                                          style: Theme.of(
                                                              context)
                                                              .textTheme
                                                              .bodyMedium
                                                              ?.copyWith(
                                                              color: Colors
                                                                  .white),
                                                        ),
                                                      ],
                                                    )),
                                              ),
                                            ),
                                          ),
                                        ),
                                      );
                                    }),
                              ),
                            ),
      SizedBox(height: 20,)
                          ],
                        ),
                      );
                    } else {

                      return  Container();
                    }
                  })),
        ],
      ),
    );
  }
}





