import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:rashno/Widgets/Text%20Fields/CustomTextField.dart';
import 'package:rashno/Widgets/TitleWidget.dart';

import '../../../Functions And Providers/Classes/RoomAndDevice.dart';
import '../../../Utils/constants/sizes.dart';

TextEditingController _NewRoomNameController = new TextEditingController();
Future<dynamic> NewRoomModalBottomSheet(BuildContext context , List<Room> roomList , Function addRoom) {
  return showModalBottomSheet(
    isScrollControlled: true,
    context: context,
    builder: (BuildContext context) {
      return Container(
        height: MediaQuery.of(context).size.height * 2 / 3,
        width: MediaQuery.of(context).size.width,
        padding: EdgeInsets.all(16.0),
        child: Column(

          children: [
            TitleWidget(text: "اضافه کردن اتاق جدید "),
            SizedBox(
              height: TSizes.xl.h,
            ),
            Text(
              'در این صفحه میتوانید اتاق جدید ایجاد کنید ',
              style: Theme.of(context).textTheme.bodyLarge,
            ),

            SizedBox(
              height: TSizes.md.h,
            ),
            CustomTextField(
                validation: (value) {
                  if (value.isEmpty) {
                    return 'لطفا نام اتاق را وارد کنید ';
                  }
                },
                hintText: 'نام اتاق',
                controller: _NewRoomNameController,
                atuoFocused: false,
                limitation: 20),
            SizedBox(
              height: TSizes.lg.h,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Expanded(
                  flex: 1,
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.of(context).pop(); // Close the bottom sheet
                    },
                    child: Text(
                      'بستن',
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                  ),
                ),
                SizedBox(
                  width: TSizes.sm.w,
                ),
                Expanded(
                  flex: 3,
                  child: ElevatedButton(
                    onPressed: () {

                        if (_NewRoomNameController.text.isNotEmpty) {
                          addRoom(_NewRoomNameController.text);
                          Navigator.of(context).pop();
                        }
                      ;
                    },
                    child: Text(
                      'ذخیره',
                      style: Theme.of(context)
                          .textTheme
                          .titleSmall
                          ?.copyWith(color: Colors.white),
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      );
    },
  );
}