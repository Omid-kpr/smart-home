import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:rashno/Functions%20And%20Providers/providers/RoomListProvider.dart';
import 'package:rashno/Ui/MainWrapper.dart';

import '../../../Functions And Providers/Classes/RoomAndDevice.dart';
import '../../../Functions And Providers/providers/themeProvider.dart';
import '../../../Utils/constants/colors.dart';
import '../../../Utils/constants/sizes.dart';
import '../../../Widgets/Text Fields/CustomTextField.dart';
import '../../../Widgets/TitleWidget.dart';

class AddDevicePage extends ConsumerStatefulWidget {
  const AddDevicePage({super.key});
  static String routName = '/UserHomePage';
  @override
  ConsumerState<AddDevicePage> createState() => _AddDevicePageState();
}

class _AddDevicePageState extends ConsumerState<AddDevicePage> {
  TextEditingController _DeviceNameController = TextEditingController();
  int _selectRoom = 0 ;


  @override
  void dispose() {
    super.dispose();
    _DeviceNameController.dispose();
  }
  @override
  void initState() {
    super.initState();
    _DeviceNameController = TextEditingController();
  }
  @override
  Widget build(BuildContext context) {
    final _roomList = ref.watch(RoomListProvider) ;
    bool _isLight = ref.watch(appThemeStateNotifier);


    return Scaffold(appBar: AppBar(), body: Container(
      height: MediaQuery.of(context).size.height * 2 / 3,
      width: MediaQuery.of(context).size.width,
      padding: EdgeInsets.all(16.0),
      child: Column(

        children: [
          TitleWidget(text: "اضافه کردن دستگاه هوشمند "),
          SizedBox(
            height: TSizes.xl.h,
          ),

          CustomTextField(
              controller: _DeviceNameController,
              validation: (value) {
                if (value.isEmpty) {
                  return 'نام دستگاه را وارد کنید ';
                }
              },
              hintText: 'نام دستگاه',
              atuoFocused: false,
              limitation: 20),
          SizedBox(
            height: TSizes.md.h,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Text('کلید به کدام اتاق اضافه شود ؟'),
            ],
          ),
          SizedBox(
            height: TSizes.md.h,
          ),
          Directionality(
            textDirection: TextDirection.rtl,
            child: SizedBox(
              height: 50.h,
              width: MediaQuery
                  .of(context)
                  .size
                  .width,
              child: ListView.builder(
                  physics: BouncingScrollPhysics(),
                  itemCount: _roomList.length,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          _selectRoom = index;
                        });


                      },
                      child: AnimatedContainer(
                        duration: Duration(milliseconds: 200),
                        margin: EdgeInsets.all(4),
                        padding: EdgeInsets.symmetric(
                            horizontal: _selectRoom == index ? 22 : 20,
                            vertical: 10),
                        height: 40.h,
                        decoration: BoxDecoration(
                          color: _selectRoom == index ? TColors.primary : Colors.transparent ,
                          border: Border.all(
                              width: _selectRoom == index ? 1.5 : 1,
                              color: _selectRoom == index
                                  ? TColors.primary
                                  : TColors.darkerGrey),
                          borderRadius: BorderRadius.circular(
                              _selectRoom == index ? 30 : 12),
                        ),
                        child: Center(
                          child: Text(_roomList[index].name,
                              style: Theme
                                  .of(context)
                                  .textTheme
                                  .bodyLarge),
                        ),
                      ),
                    );
                  }),
            ),
          ),
          SizedBox(
            height: TSizes.xl.h,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(
                flex: 1,
                child: OutlinedButton(
                  onPressed: () {
                    Navigator.pushNamed(context, MainWrapper.routName);
                  },
                  child: Text(
                    'انصراف',
                    style: Theme
                        .of(context)
                        .textTheme
                        .titleSmall,
                  ),
                ),
              ),
              SizedBox(
                width: TSizes.sm.w,
              ),
              Expanded(
                flex: 3,
                child: ElevatedButton(
                  onPressed: () {

                    if (_DeviceNameController.text.isNotEmpty) {
                      Device newDevice = Device(
                          name: _DeviceNameController.text,
                          icon: Icons.lightbulb);

                      _roomList[_selectRoom].devices.add(newDevice);

                      Navigator.pushNamed(context, MainWrapper.routName);
                    }
else {Navigator.pop(context);}
                  },
                  child: Text(
                    'ذخیره',
                    style: Theme
                        .of(context)
                        .textTheme
                        .titleSmall
                        ?.copyWith(color: Colors.white),
                  ),
                ),
              ),
            ],
          )
        ],
      ),
    ) ,) ;
      }

  }

