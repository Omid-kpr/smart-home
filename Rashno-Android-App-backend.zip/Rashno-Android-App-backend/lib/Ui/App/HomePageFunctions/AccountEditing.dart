import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:rashno/Widgets/Text%20Fields/CustomTextField.dart';
import 'package:rashno/Widgets/TitleWidget.dart';
import 'package:rashno/utils/constants/sizes.dart';
import '../../../Functions And Providers/providers/UserProvider.dart';


class AccountEditing extends ConsumerStatefulWidget {
  const AccountEditing({super.key});

  @override
  ConsumerState<AccountEditing> createState() => _AccountEditingState();
}

TextEditingController _NewUserNameController = TextEditingController();

class _AccountEditingState extends ConsumerState<AccountEditing> {
  @override
  Widget build(BuildContext context) {

    final user = ref.watch(userProvider);

    return InkWell(
      onTap: () {
        showModalBottomSheet<void>(
          isScrollControlled: true,
          context: context,
          builder: (BuildContext context) {
            return Container(
              height: MediaQuery.of(context).size.height * 2 / 3,
              width: MediaQuery.of(context).size.width,
              padding: EdgeInsets.all(16.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TitleWidget(text: "ویرایش اطلاعات"),
                  SizedBox(
                    height: TSizes.xl.h,
                  ),
                  Text(
                    'اطلاعات حساب کاربری را ویرایش کنید',
                    style: Theme.of(context).textTheme.bodyLarge,
                  ),
                  SizedBox(
                    height: TSizes.md.h,
                  ),
                  CustomTextField(
                      validation: (value) {
                        if (value.isEmpty) {
                          return 'لطفا نام خود را وارد کنید ';
                        }

                      },
                      hintText: 'نام جدید ',
                      controller: _NewUserNameController,
                      atuoFocused: false,
                      limitation: 20),
                  SizedBox(
                    height: TSizes.sm.h,
                  ),

                  SizedBox(
                    height: TSizes.md.h,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Expanded(
                        flex: 1,
                        child: OutlinedButton(
                          onPressed: () {
                            Navigator.of(context)
                                .pop(); // Close the bottom sheet
                          },
                          child: Text(
                            'بستن',
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: TSizes.sm.w,
                      ),
                      Expanded(
                        flex: 3,
                        child: ElevatedButton(
                          onPressed: () {

                            ref.read(userProvider.notifier).updateName(_NewUserNameController.text.toString());
                            Navigator.pop(context) ;

                          },
                          child: Text(
                            'ذخیره',
                            style: Theme.of(context)
                                .textTheme
                                .titleSmall
                                ?.copyWith(color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            );
          },
        );

      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 20 ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Icon(FontAwesomeIcons.pen , size: 18,) ,
            Text('ویرایش اطلاعات' , style: Theme.of(context).textTheme.titleMedium,)

          ],),
      ),
    );
  }
}


