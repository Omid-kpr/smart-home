import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:rashno/Widgets/Text%20Fields/CustomTextField.dart';
import 'package:rashno/Widgets/TitleWidget.dart';

import '../../../Utils/constants/sizes.dart';


class AddNewHome extends StatefulWidget {
  const AddNewHome({super.key});

  @override
  State<AddNewHome> createState() => _AddNewHomeState();
}

TextEditingController _NewHomeNameController = TextEditingController();

class _AddNewHomeState extends State<AddNewHome> {
  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: () {
     //   _openAddDeviceModal(context);
      },
     child: Text(
        'خوش آمدید ',
        style: Theme.of(context)
            .textTheme
            .headlineMedium
            ?.copyWith(fontSize: 22, fontWeight: FontWeight.w500),
      ),

    );
  }
}

void _openAddDeviceModal(BuildContext context) {
  showModalBottomSheet(
    isScrollControlled: true,
    context: context,
    builder: (BuildContext context) {
      return Container(
        height: MediaQuery.of(context).size.height * 2/3  ,
        width: MediaQuery.of(context).size.width,
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TitleWidget(text: "اضافه کردن خانه جدید  ") ,

            SizedBox(
              height: TSizes.xl.h,
            ),
            Text(
              'در این صفحه میتوانید خانه جدید ایجاد کنید ',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            SizedBox(
              height: TSizes.md.h,
            ),

            CustomTextField(


                validation: (value) {
                  if (value.isEmpty) {
                    return 'لطفا نام خود را وارد کنید ';
                  }
                },
                hintText: 'نام خانه',
                controller: _NewHomeNameController,
                atuoFocused: false,
                limitation: 20),
            SizedBox(
              height: TSizes.lg.h,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

              Expanded(
                flex: 1,
                child: OutlinedButton(
                  onPressed: () {
                    Navigator.of(context).pop(); // Close the bottom sheet
                  },
                  child: Text(
                    'بستن',
                    style: Theme.of(context).textTheme.titleSmall,
                  ),
                ),
              ),
                SizedBox(
                  width: TSizes.sm.w,
                ),
                Expanded(
                  flex: 3,
                  child: ElevatedButton(
                    onPressed: () {

                    },
                    child: Text(
                      'ذخیره',
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(color: Colors.white),
                    ),
                  ),
                ),

            ],)

          ],
        ),
      );
    },
  );
}
