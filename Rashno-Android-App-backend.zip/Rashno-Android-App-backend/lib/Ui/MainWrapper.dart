import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:rashno/ui/App/HomePage.dart';
import 'package:rashno/ui/App/Settings.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import '../Functions And Providers/providers/themeProvider.dart';
import '../utils/constants/colors.dart';
import 'App/Rooms.dart';


class MainWrapper extends ConsumerStatefulWidget {
  const MainWrapper({super.key});

  static String routName = '/MainWrapper';

  @override
  ConsumerState<MainWrapper> createState() => _MainWrapperState();
}

int pageNumber = 1;

class _MainWrapperState extends ConsumerState<MainWrapper> {
  PageController _myPage = PageController(initialPage: pageNumber);

  @override
  Widget build(BuildContext context) {
    final isLightTheme = ref.watch(appThemeStateNotifier);
    return Scaffold(
      bottomNavigationBar: GNav_Method(isLightTheme, context),
      body: PageView(
        physics: NeverScrollableScrollPhysics(),

        onPageChanged: (index) {
          setState(() {
            pageNumber = index;
          });
        },
        controller: _myPage,
        children: [
          Settings(),
          HomePage(),
          Rooms(),
        //  UserAccount(),
        ],
      ),
    );
  }

  Container GNav_Method(bool isLightTheme, BuildContext context) {
    return Container(
      color: isLightTheme ? TColors.lightContainer : TColors.DarkerScaffoldBack,
      padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 12),
      child: GNav(
        tabBackgroundColor:
            isLightTheme ? TColors.primaryLight : TColors.primarydark,
        backgroundColor: isLightTheme ? TColors.lightContainer : TColors.DarkerScaffoldBack,
        // tabActiveBorder: Border.all(color:  Colors.grey, width: 1),
        textStyle: Theme.of(context).textTheme.titleMedium?.copyWith(
            color: isLightTheme ? TColors.primary : TColors.primaryLight),
        selectedIndex: pageNumber,
        onTabChange: (index) {
          setState(() {
            pageNumber = index;
            _myPage.animateToPage(pageNumber,
                duration: Duration(milliseconds: 300), curve: Curves.easeInOut);
          });
        },
        iconSize: 20,
        padding: const EdgeInsets.all(16.0),
        gap: 14.h,
        tabs: [
          GButton(
            icon: FontAwesomeIcons.gear,
            text: 'تنظیمات',
            iconColor: isLightTheme ? TColors.black : TColors.white,
            iconActiveColor:
                isLightTheme ? TColors.primary : TColors.primaryLight,
          ),
          GButton(
            icon: FontAwesomeIcons.house,
            text: 'خانه',
            iconColor: isLightTheme ? TColors.black : TColors.white,
            iconActiveColor:
                isLightTheme ? TColors.primary : TColors.primaryLight,
          ),
          GButton(
            icon: Icons.window,
            text: "اتاق ها",
            iconColor: isLightTheme ? TColors.black : TColors.white,
            iconActiveColor:
            isLightTheme ? TColors.primary : TColors.primaryLight,
          ),
          // GButton(
          //   icon: Icons.timer,
          //   text: "سناریو",
          //   iconColor: isLightTheme ? TColors.black : TColors.white,
          //   iconActiveColor:
          //   isLightTheme ? TColors.primary : TColors.primaryLight,
          // ),
          // GButton(
          //   icon: FontAwesomeIcons.userGear,
          //   text: "حساب کاربری",
          //   iconColor: isLightTheme ? TColors.black : TColors.white,
          //   iconActiveColor:
          //       isLightTheme ? TColors.primary : TColors.primaryLight,
          // ),
        ],
      ),
    );
  }
}
