
import 'package:flutter/cupertino.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class User {
  String phone;
  String name;

//<editor-fold desc="Data Methods">
  User({
    required this.phone,
    required this.name,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is User &&
          runtimeType == other.runtimeType &&
          phone == other.phone &&
          name == other.name);

  @override
  int get hashCode => phone.hashCode ^ name.hashCode;

  @override
  String toString() {
    return 'User{' + ' phone: $phone,' + ' name: $name,' + '}';
  }

  User copyWith({
    String? phone,
    String? name,
  }) {
    return User(
      phone: phone ?? this.phone,
      name: name ?? this.name,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'phone': this.phone,
      'name': this.name,
    };
  }

  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      phone: map['phone'] as String,
      name: map['name'] as String,
    );
  }

//</editor-fold>
}


// methods for updating user information
class UserNotifier extends StateNotifier<User> {
  UserNotifier(super.state);
 void updateName(String n) {

state = state.copyWith(name: n);
 }

}