import 'package:flutter/cupertino.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:uuid/uuid.dart';
Uuid uuid = Uuid() ;

class Room {
  String name;
  String id ;
  final List<Device> devices;

//<editor-fold desc="Data Methods">
  Room({
    required this.name,

  }): id = Uuid().v4() , devices = [] ;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Room &&
          runtimeType == other.runtimeType &&
          name == other.name &&
          devices == other.devices);

  @override
  int get hashCode => name.hashCode ^ devices.hashCode;

  @override
  String toString() {
    return 'Room{' + ' name: $name,' + ' devices: $devices,' + '}';
  }

  Room copyWith({
    String? name,
    List<Device>? devices,
  }) {
    return Room(
      name: name ?? this.name,

    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': this.name,
      'devices': this.devices,
    };
  }

  factory Room.fromMap(Map<String, dynamic> map) {
    return Room(
      name: map['name'] as String,

    );
  }

//</editor-fold>
}
final roomProvider = StateNotifierProvider<RoomNotifier , Room>((ref) => RoomNotifier(Room( name: '' ))) ;
class RoomNotifier extends StateNotifier<Room> {
  RoomNotifier(super.state);
  void updateRoomName(String n) {

    state = state.copyWith(name: n);
  }

}



//----------------------------------------------------------------`



class Device {
  String name;
  IconData icon ;
  bool onOff;
  String id ;

//<editor-fold desc="Data Methods">
  Device({
    required this.name,
    required this.icon,

  }) : id = Uuid().v4() , onOff = false;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Device &&
          runtimeType == other.runtimeType &&
          name == other.name &&
          icon == other.icon);

  @override
  int get hashCode => name.hashCode ^ icon.hashCode;

  @override
  String toString() {
    return 'Device{' + ' name: $name,' + ' icon: $icon,' + '}';
  }

  Device copyWith({
    String? name,
    IconData? icon,
  }) {
    return Device(
      name: name ?? this.name,
      icon: icon ?? this.icon,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': this.name,
      'icon': this.icon,
    };
  }

  factory Device.fromMap(Map<String, dynamic> map) {
    return Device(
      name: map['name'] as String,
      icon: map['icon'] as IconData,
    );
  }

//</editor-fold>
}
final devcieProvider = StateNotifierProvider<DeviceNotifier ,Device >((ref) => DeviceNotifier(Device ( name: '',  icon: FontAwesomeIcons.lightbulb))) ;
class DeviceNotifier extends StateNotifier<Device> {
  DeviceNotifier(super.state);
  void updateDeviceName(String n) {

    state = state.copyWith(name: n);
  }

}

