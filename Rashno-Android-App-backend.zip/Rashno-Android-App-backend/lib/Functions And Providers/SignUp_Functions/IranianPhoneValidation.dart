



String? validatePhoneNumber(String? value) {
  if (value == null || value.isEmpty) {
    return "شماره تلفن را وارد کنید";
  }
  RegExp regex = RegExp(r'^(?:(?:(?:\\+?|00)(98))|(0))?((?:90|91|92|93|99)[0-9]{8})$');
  if (!regex.hasMatch(value)) {
    return "شماره نامعتبر";
  }
  return null;

}


//
// bool validatePhoneNumber(String? value) {
//   if (value == null || value.isEmpty) {
//     return false;
//   }
//   RegExp regex = RegExp(r'^09(1[0-9]|3[1-9])-?[0-9]{3}-?[0-9]{4}$');
//   if (!regex.hasMatch(value)) {
//     return false;
//   }
//   return true; // Validation passed
// }
//

