


import 'package:flutter/animation.dart';

String? validatePassword(String? value) {
  if (value == null || value.isEmpty) {
    return "رمز را وارد کنید ";
  }
  RegExp regex1 = RegExp(r'^(?=.*[0-9])(?=.*[a-z]).{8,32}$');
  if (!regex1.hasMatch(value)) {
    return "رمز عبور نامعتبر ";
  }
  return null;



}

