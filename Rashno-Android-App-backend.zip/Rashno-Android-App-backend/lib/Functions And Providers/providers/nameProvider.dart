import 'package:flutter_riverpod/flutter_riverpod.dart';


final nameProvider = StateProvider<String?> ((ref) => null) ;
