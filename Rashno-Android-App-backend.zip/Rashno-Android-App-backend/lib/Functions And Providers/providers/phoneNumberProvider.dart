
import 'package:flutter_riverpod/flutter_riverpod.dart';



final PhoneNumberProvider = StateProvider<String?> ((ref) => null) ;









