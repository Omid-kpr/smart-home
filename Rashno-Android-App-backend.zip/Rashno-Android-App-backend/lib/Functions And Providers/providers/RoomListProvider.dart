import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../Classes/RoomAndDevice.dart';

final RoomListProvider = StateProvider<List<Room>> ((ref) => [
  Room(name: 'پذیرایی'),
  Room(name: 'آشپزخانه'),
  Room(name: 'اتاق خواب'),
  Room(name: 'حمام'),

   ] ,) ;