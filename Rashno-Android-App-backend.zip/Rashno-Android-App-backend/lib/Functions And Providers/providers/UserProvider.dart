

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:rashno/Functions%20And%20Providers/Classes/UserClass.dart';


final userProvider = StateNotifierProvider<UserNotifier , User>((ref) => UserNotifier(User(phone: '', name: ''))) ;

