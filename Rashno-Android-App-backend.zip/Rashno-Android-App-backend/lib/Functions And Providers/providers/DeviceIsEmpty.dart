import 'package:flutter_riverpod/flutter_riverpod.dart';

final DeviceIsEmpty = StateProvider<bool?> ((ref) => true) ;