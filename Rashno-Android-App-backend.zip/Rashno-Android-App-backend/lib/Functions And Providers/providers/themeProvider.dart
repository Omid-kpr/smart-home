import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';


final appThemeStateNotifier = StateProvider<bool>((ref) => false);



class ThemeProvider extends ChangeNotifier {
  ThemeMode themeMode=   ThemeMode.light ;

  bool get isDarkMode => themeMode == ThemeMode.dark ;

  void toggleTheme  () {
    themeMode = themeMode == ThemeMode.light ? ThemeMode.dark : ThemeMode.light ;

    notifyListeners() ;

  }


}






