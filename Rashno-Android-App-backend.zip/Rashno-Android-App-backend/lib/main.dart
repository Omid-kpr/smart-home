import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:rashno/ui/App/UserAccount.dart';
import 'package:rashno/ui/Login%20Route/LoginPage.dart';
import 'package:rashno/ui/Login%20Route/Login_Validation.dart';
import 'package:rashno/ui/Login%20Route/Login_with_Phone.dart';
import 'package:rashno/ui/MainWrapper.dart';
import 'package:rashno/ui/SignUp%20Route/Signup_Form.dart';
import 'package:rashno/ui/SignUp%20Route/Signup_Screen.dart';
import 'package:rashno/ui/SignUp%20Route/Signup_Validation.dart';
import 'package:rashno/ui/StartScreens/StartScreen.dart';
import 'package:rashno/utils/theme/theme.dart';
import 'Functions And Providers/providers/themeProvider.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'Ui/App/HomePageFunctions/AddDevicePage.dart';








main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]);

  runApp(ProviderScope(
    child: MyApp(),
  ));
}

class MyApp extends ConsumerWidget {
  const MyApp({super.key});


  // This widget is the root of your application.
  @override
  Widget build(BuildContext, WidgetRef ref) {
    final isLightTheme = ref.watch(appThemeStateNotifier);
    return ScreenUtilInit(
      designSize: Size(375, 812),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Rashno IOT',
        theme: isLightTheme ? TAppTheme.lightTheme : TAppTheme.darkTheme,

        themeMode: ThemeMode.system,

        routes: {
          Login_Screen.routName: (context) => Login_Screen(),
          Signup_Screen.routName: (context) => Signup_Screen(),
          // HomePage.routName: (context) => const HomePage(),
          StartScreen.routName: (context) => StartScreen(),
          Signup_Validation.routName: (context) => Signup_Validation(),
          Login_Otp_Validation.routName: (context) => Login_Otp_Validation(),
          LoginWithPhone.routName: (context) => LoginWithPhone(),
          Signup_Form.routName: (context) => Signup_Form(),
          MainWrapper.routName: (context) => MainWrapper(),
          UserAccount.routName: (context) =>UserAccount(),
          AddDevicePage.routName: (context) =>AddDevicePage()


        },
          initialRoute: StartScreen.routName,
        // can use Directionality Widget in home :  !

      ),
    );
  }
}

//ToDO : implement .env
// ToDO : implement   Go rout
// ToDO : implement  OTP widget
// ToDO : implement  user Classes

