import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../Const/styles.dart';
import '../../Functions And Providers/Classes/RoomAndDevice.dart';
import 'TestWidgets/TouchableBox.dart';

class FullHomeDeviceBuilder extends StatelessWidget {
    FullHomeDeviceBuilder({
    super.key, required this.roomList,
    required this.CurrentRoom ,
  });
  final List<Room>  roomList ;
  int CurrentRoom ;
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        physics: ScrollPhysics(),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4 ,

        ),
        itemCount: roomList[CurrentRoom].devices.length,
        shrinkWrap: true,
        itemBuilder: (context, index) {
          return Column(
            children: [

              TouchableBox(
                width: 80,
                height: 90,
                borderRadius: kBorderRadius,
                icon:  roomList[CurrentRoom].devices[index].icon   ,
                text: roomList[CurrentRoom].devices[index].name,
                powerOnOff: roomList[CurrentRoom].devices[index].onOff,
              ),

            ],
          );
        });
  }
}

