import 'package:flutter/material.dart';
import 'package:rashno/Const/styles.dart';


class My_Elevated_Button extends StatelessWidget {
    My_Elevated_Button({super.key , required this.lableText , required this.onPressed,   required this.color});
   final Function()  onPressed ;
final Color color ;
  final String lableText ;
  @override
  Widget build(BuildContext context) {
    return   ConstrainedBox(
      constraints: BoxConstraints(  minHeight: 50 , maxHeight: 50),
      child: ElevatedButton(

        style: ElevatedButton.styleFrom( backgroundColor: color ,



        ),


        onPressed: onPressed ,


        child: Text( lableText , style: TextStyle(color: Colors.white),    ),
      ),
    ) ;
  }
}
