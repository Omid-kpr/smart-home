import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:rounded_loading_button/rounded_loading_button.dart';


import '../../Const/styles.dart';
import '../../utils/constants/colors.dart';


class CustomLoadingButton extends StatefulWidget {
  const CustomLoadingButton({super.key, required this.Controller, required this.onPressed, required this.text });
  final RoundedLoadingButtonController  Controller ;
  final VoidCallback  onPressed ;
final String text ;
  @override
  State<CustomLoadingButton> createState() => _CustomLoadingButtonState();
}

class _CustomLoadingButtonState extends State<CustomLoadingButton> {




  @override
  Widget build(BuildContext context) {
    return RoundedLoadingButton(
      height: 50 ,
      width: 400.w,
      borderRadius: 12,
      color: kAccentColor,
      resetAfterDuration: true,
      resetDuration: const Duration(seconds: 2),
      child: Text(widget.text, style: const TextStyle(fontSize: 18, color: TColors.textWhite, fontWeight: FontWeight.w600 , fontFamily: 'yekan'),),
      controller:  widget.Controller,
      onPressed: widget.onPressed ,
    );
  }
}
