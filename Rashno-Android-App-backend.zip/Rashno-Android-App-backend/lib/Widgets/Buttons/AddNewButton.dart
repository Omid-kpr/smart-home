import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:rashno/Functions%20And%20Providers/providers/themeProvider.dart';


import '../../Utils/constants/colors.dart';

class AddNewButton extends ConsumerWidget {
  AddNewButton( { required this.text, required this.icon, required this.onTab,
    super.key
  } );
   String text ;
   IconData icon ;
  VoidCallback onTab ;
  @override
  Widget build(BuildContext context , WidgetRef ref) {

    bool _islight = ref.watch(appThemeStateNotifier) ;
    return GestureDetector(
      onTap: onTab,
      child: Container(
        width: MediaQuery.of(context).size.width,
        height: 70.h,
        decoration: BoxDecoration(
            color:_islight ? TColors.primaryLight : TColors.Offcolor ,
            borderRadius: BorderRadius.circular(30)),
        child: Directionality(
          textDirection: TextDirection.rtl,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              SizedBox(child: Text(text) , width: 200.w,),
              Icon(icon , size: 24,),
            ],
          ),
        ),
      ),
    );
  }
}