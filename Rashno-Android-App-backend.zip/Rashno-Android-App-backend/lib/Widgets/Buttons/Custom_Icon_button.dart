import 'package:flutter/material.dart';

class Custom_Icon_Button extends StatelessWidget {
  Custom_Icon_Button({super.key, required this.icon , required this.onClick});
  VoidCallback onClick ;
  Icon icon;

  @override
  Widget build(BuildContext context) {
    return IconButton(onPressed: onClick, icon: icon);
  }
}


