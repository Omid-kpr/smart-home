import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../utils/constants/sizes.dart';

void  ContactSheet(BuildContext context) {
  showModalBottomSheet(
    isScrollControlled: true,
    context: context,
    builder: (BuildContext context) {
      return Container(
        height: MediaQuery.of(context).size.height * 1 / 2,
        width: MediaQuery.of(context).size.width,
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'راه های ارتباطی',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            SizedBox(
              height: TSizes.xl.h,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [


                      SelectableText(
                        '۰۹۱۷۴۸۳۱۶۷۲',
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                      SizedBox(
                        width: TSizes.sm.w,
                      ),
                      Icon(FontAwesomeIcons.phone),
                    ],
                  ),
                  Divider(),
                  SizedBox(
                    height: TSizes.sm.h,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [


                      SelectableText(
                        'rashno2023@gmail.com',
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                      SizedBox(
                        width: TSizes.sm.w,
                      ),
                      Icon(FontAwesomeIcons.envelope),
                    ],
                  ),
                  Divider(),
                  SizedBox(
                    height: TSizes.sm.h,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [


                      InkWell(

                        child: SelectableText(
                          'rashnoiot.com',
                          style: Theme.of(context).textTheme.bodyLarge,
                        ),
                      ),
                      SizedBox(
                        width: TSizes.sm.w,
                      ),
                      Icon(FontAwesomeIcons.globe),
                    ],
                  ),
                  Divider(),
                  SizedBox(
                    height: TSizes.sm.h,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [


                      SelectableText(
                        'rashnoiot',
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                      SizedBox(
                        width: TSizes.sm.w,
                      ),
                      Icon(FontAwesomeIcons.instagram),
                    ],
                  ),
                  SizedBox(
                    height: TSizes.sm.h,
                  ),

                  Divider(),
                ],
              ),
            ),

            SizedBox(
              height: TSizes.lg.h,
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the bottom sheet
              },
              child: Text(
                'بستن',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(color: Colors.white),
              ),
            ),
          ],
        ),
      );
    },
  );
}