import 'package:flutter/material.dart';

class VerticalSlider extends StatefulWidget {
  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;

  VerticalSlider({
    required this.value,
    required this.min,
    required this.max,
    required this.onChanged,
  });

  @override
  _VerticalSliderState createState() => _VerticalSliderState();
}

class _VerticalSliderState extends State<VerticalSlider> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200.0,
      width: 40.0,
      child: RotatedBox(
        quarterTurns: 3,
        child: Slider(
          value: widget.value,
          min: widget.min,
          max: widget.max,
          onChanged: widget.onChanged,
          activeColor: Colors.blue,
          inactiveColor: Colors.grey,
          divisions: (widget.max - widget.min) ~/ 1,
        ),
      ),
    );
  }
}