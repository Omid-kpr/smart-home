import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter/material.dart';
import 'package:zoom_tap_animation/zoom_tap_animation.dart';
import '../../Functions And Providers/providers/RoomListProvider.dart';
import '../../Functions And Providers/providers/themeProvider.dart';
import '../../Utils/constants/colors.dart';
class TouchableBox extends ConsumerStatefulWidget {
  final IconData icon;
  final String text;
  late  bool powerOnOff;
final double width;
final double height;
final int  currentRoom ;
final int currentIndex ;
  final double borderRadius;
  TouchableBox({required this.icon, required this.text , required this.powerOnOff, required this.width, required this.height, required this.borderRadius , required this.currentRoom , required this.currentIndex});

  @override




  _TouchableBoxState createState() => _TouchableBoxState();
}

class _TouchableBoxState extends ConsumerState<TouchableBox> {


  @override


  Widget build(BuildContext context) {
    final _roomList = ref.watch(RoomListProvider);
    bool _isLight = ref.watch(appThemeStateNotifier);

    Color _BoxColor ( ) {
      if (widget.powerOnOff && _isLight ) {
        return TColors.OnColorLight ;
      }
      else if (widget.powerOnOff == false  && _isLight )  {
        return  TColors.primarydark ;
      }
      else if (widget.powerOnOff == false && _isLight == false ){

        return  TColors.Offcolor ;
      }
      else {   return TColors.OnColor ; }
    }

    return ZoomTapAnimation(
      child: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTap: () {
          setState(() {

            widget.powerOnOff =!widget.powerOnOff;
            _roomList[widget.currentRoom].devices[widget.currentIndex].onOff =  widget.powerOnOff ;
          });
        },
        onLongPress: () {

          } ,
        child: Column(

          children: [

            ConstrainedBox(
              constraints: BoxConstraints(minWidth: 150.w , minHeight: 150.h ),
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 16 ),
                // width: widget.width,
                // height: widget.height ,
                decoration: BoxDecoration(
                  color:  _BoxColor ( )  ,
                  borderRadius: BorderRadius.circular(20 ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: EdgeInsets.all(8),
                      decoration: BoxDecoration(borderRadius : BorderRadius.circular(15) ,color : widget.powerOnOff ? TColors.boxIcon_on :TColors.boxIcon_off ) ,
                      child: Icon(
                        widget.icon,
                        size: 34,
                        color: widget.powerOnOff ? Colors.white   :TColors.iconPrimary,
                      ),
                    ),

                    SizedBox(height: 18.h),
                    Directionality(
                      textDirection: TextDirection.rtl,
                      child: Text(
                        widget.text,
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(color: Colors.white , fontSize : 18 ) ,
                      ),
                    ),
                    SizedBox(height: 10.h),
                    Text(
                      widget.powerOnOff ? 'روشن' : "خاموش",
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(fontSize : 14 ,color:  widget.powerOnOff ? Colors.white   : Colors.white70) ,
                    ),

                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}





