import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class ResponsiveWidget extends StatelessWidget {
  final Widget child;
  final double maxWidth;

  ResponsiveWidget({required this.child, required this.maxWidth});

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double constrainedWidth = screenWidth > maxWidth ? maxWidth : screenWidth;

    return ConstrainedBox(
      constraints: BoxConstraints(
        maxWidth:   maxWidth.h,
      ),
      child: child,
    );
  }
}

