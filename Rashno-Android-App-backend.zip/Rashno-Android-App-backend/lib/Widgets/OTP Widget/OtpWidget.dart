import 'package:flutter/material.dart';
import 'package:pinput/pinput.dart';

import '../../Const/styles.dart';
import '../../utils/constants/colors.dart';


class OtpWidget extends StatefulWidget {
  const OtpWidget({Key? key, this.validation, this.onComplete});
  final Function? onComplete ;
  final Function(String)? validation;
  @override
  State<OtpWidget> createState() => _OtpWidgetState();
}

class _OtpWidgetState extends State<OtpWidget> {
  @override
  Widget build(BuildContext context) {
    // customizations for the Pin-out widget
    final defaultPinTheme = PinTheme(
      width: 56,
      height: 56,
      textStyle: Theme.of(context).textTheme.headlineMedium,
      decoration: BoxDecoration(
        border: Border.all(color: kAccentColor),
        borderRadius: BorderRadius.circular(8),
      ),
    );
    final focusedPinTheme = defaultPinTheme.copyDecorationWith(
      border: Border.all(color: kAccentColor),
      color: Colors.black12,
      borderRadius: BorderRadius.circular(12),
    );

    final submittedPinTheme = defaultPinTheme.copyWith(
      decoration: defaultPinTheme.decoration?.copyWith(
        color: TColors.primary,
      ),
    );
    // end of customizations for Pin_out widget

    return Container(
      child: Pinput(
        key: widget.key,
        keyboardType: TextInputType.number,
        length: 4,
        autofocus: true,
        defaultPinTheme: defaultPinTheme,
        focusedPinTheme: focusedPinTheme,
        submittedPinTheme: submittedPinTheme,
       validator: (value) => widget.validation!(value!),
        closeKeyboardWhenCompleted: true,
        isCursorAnimationEnabled: true,
        pinputAutovalidateMode: PinputAutovalidateMode.onSubmit,
        androidSmsAutofillMethod: AndroidSmsAutofillMethod.smsRetrieverApi,
        showCursor: true,
        onCompleted: (pin) =>widget.onComplete!(pin),
      ),
    );
  }
}



