import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../Functions And Providers/providers/themeProvider.dart';








class ThemeSwitcher extends ConsumerStatefulWidget {
  const ThemeSwitcher({super.key});

  @override
  ConsumerState<ThemeSwitcher> createState() => _ThemeSwitcherState();
}

class _ThemeSwitcherState extends ConsumerState<ThemeSwitcher> {
  @override
  Widget build(BuildContext context) {
    final _isLightTheme =  ref.watch(appThemeStateNotifier) ;



    return IconButton(

      icon: Icon(
        _isLightTheme ? Icons.sunny :  Icons.nightlight_round ,


      ), onPressed: () {

        ref.read(appThemeStateNotifier.notifier).state = !_isLightTheme ;


    },
    );
  }
}




