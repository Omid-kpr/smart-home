import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:rashno/Const/styles.dart';

import '../../utils/constants/colors.dart';

class CustomPassWord extends StatefulWidget {
  CustomPassWord(
      {super.key,
      required this.obscureText,
      required this.hintText,
      required this.controller,
      this.onChanged,
      this.validation,
      required this.limitation});

  final int limitation;

  final String hintText;
  final bool obscureText;
  final Function(String)? validation;
  final Function(String)? onChanged;
  late   TextEditingController controller;

  @override
  State<CustomPassWord> createState() => _CustomPassWordState();
}

class _CustomPassWordState extends State<CustomPassWord> {
  static bool get obscureText => false;














  //static String get hintText => 'رمز' ;
  bool _passwordVisible = obscureText;

  get userPassword => null;

  @override
  Widget build(BuildContext context) {

    return Directionality(
      textDirection: TextDirection.rtl,
      child: TextFormField(
      //  textDirection: TextDirection.rtl ,
        validator: (value) => widget.validation!(value!),
        onChanged: widget.onChanged,
        textAlign: TextAlign.right,
        keyboardType: TextInputType.visiblePassword,
        controller: widget.controller,
        obscureText: !_passwordVisible,
        inputFormatters: [
          LengthLimitingTextInputFormatter(widget.limitation)
        ],
        decoration: InputDecoration(
           // hintText: widget.hintText,
labelText:widget.hintText ,
          floatingLabelBehavior: FloatingLabelBehavior.auto,
          labelStyle: Theme.of(context).textTheme.bodyMedium,
          floatingLabelStyle: Theme.of(context).textTheme.headlineSmall,
          alignLabelWithHint: false,
          hintStyle: TextStyle(color: Colors.grey),
          hintTextDirection: TextDirection.rtl,
          floatingLabelAlignment: FloatingLabelAlignment.center ,

            prefixIcon: IconButton(
              icon: Icon(
                !_passwordVisible ? Icons.visibility : Icons.visibility_off,

              color: TColors.iconPrimary,),
              onPressed: () {
                setState(() {
                  _passwordVisible = !_passwordVisible;
                });
              },
            ),

            //----------------------------------------------------------------
          ),
      ),
    );
  }
}
