import 'package:flutter/material.dart';
import 'package:pinput/pinput.dart';
import '../../Const/styles.dart';

class OTP_TextField extends StatelessWidget {


    OTP_TextField({
    super.key,
  });
  @override
  Widget build(BuildContext context) {
    final defaultPinTheme = PinTheme(
      width: 56,
      height: 56,
      textStyle: TextStyle(fontSize: 20, color: Colors.white60, fontWeight: FontWeight.w600),
      decoration: BoxDecoration(
        border: Border.all(color: kAccentColor),
        borderRadius: BorderRadius.circular(8),

      ),
    );
    final focusedPinTheme = defaultPinTheme.copyDecorationWith(
      border: Border.all(color:kAccentColor),
      color: Colors.black12,
      borderRadius: BorderRadius.circular(15),
    );

    final submittedPinTheme = defaultPinTheme.copyWith(
      decoration: defaultPinTheme.decoration?.copyWith(
        color: kAccentColor,
      ),
    );



    return Container(
      child: Pinput(
        length: 4,
         autofocus: true,
        defaultPinTheme: defaultPinTheme,
        focusedPinTheme: focusedPinTheme,
        submittedPinTheme: submittedPinTheme,
        validator: (s) {
          return s == '2222' ? null : 'کد تایید نادرست است';
        },
        pinputAutovalidateMode: PinputAutovalidateMode.onSubmit,
        showCursor: true,
        onCompleted: (pin) => print(pin),


      ),

    );



  }
}



//
// SizedBox(
// height: 64,
// width: 68,
// child: TextFormField(
// autofocus: true,
// onChanged: (value) {
//
// if (value.length == 1) {
// FocusScope.of(context).nextFocus();
//
// }
//
// },
// onSaved: (pin1){},
// textAlign: TextAlign.center,
// textDirection: TextDirection.ltr,
// decoration: InputDecoration(
// hintText: '0',
// contentPadding: const EdgeInsets.all(18),
// enabledBorder: OutlineInputBorder(
// borderSide: const BorderSide(
// color: Colors.white60,
// width: 1,
// ),
// borderRadius: BorderRadius.circular(10)),
// focusedBorder: OutlineInputBorder(
// borderSide:   BorderSide(
// color: kAccentColor,
// width: 2,
// ),
// borderRadius: BorderRadius.circular(15))),
// style: Theme.of(context).textTheme.headline6,
// keyboardType: TextInputType.number,
// inputFormatters: [
// LengthLimitingTextInputFormatter(1),
// FilteringTextInputFormatter.digitsOnly,
// ],
// ),
// ),
// SizedBox(
// height: 64,
// width: 68,
// child: TextFormField(
// onChanged: (value) {
//
// if (value.length == 1) {
// FocusScope.of(context).nextFocus();
//
// }
//
// },
//
// textAlign: TextAlign.center,
// onSaved: (pin2){},
// textDirection: TextDirection.ltr,
// decoration: InputDecoration(
// hintText: '0',
// contentPadding: const EdgeInsets.all(18),
// enabledBorder: OutlineInputBorder(
// borderSide: const BorderSide(
// color: Colors.white60,
// width: 1,
// ),
// borderRadius: BorderRadius.circular(10)),
// focusedBorder: OutlineInputBorder(
// borderSide:   BorderSide(
// color: kAccentColor,
// width: 2,
// ),
// borderRadius: BorderRadius.circular(15))),
// style: Theme.of(context).textTheme.headline6,
// keyboardType: TextInputType.number,
// inputFormatters: [
// LengthLimitingTextInputFormatter(1),
// FilteringTextInputFormatter.digitsOnly,
// ],
// ),
// ),
// SizedBox(
//
// height: 64,
// width: 68,
// child: TextFormField(
// onChanged: (value) {
//
// if (value.length == 1) {
// FocusScope.of(context).nextFocus();
//
// }
//
// },
// onSaved: (pin3){},
// textAlign: TextAlign.center,
// textDirection: TextDirection.ltr,
// decoration: InputDecoration(
// hintText: '0',
// contentPadding: const EdgeInsets.all(18),
// enabledBorder: OutlineInputBorder(
// borderSide: const BorderSide(
// color: Colors.white60,
// width: 1,
// ),
// borderRadius: BorderRadius.circular(10)),
// focusedBorder: OutlineInputBorder(
// borderSide:  BorderSide(
// color:  kAccentColor,
// width: 2,
// ),
// borderRadius: BorderRadius.circular(15))),
// style: Theme.of(context).textTheme.headline6,
// keyboardType: TextInputType.number,
// inputFormatters: [
// LengthLimitingTextInputFormatter(1),
// FilteringTextInputFormatter.digitsOnly,
// ],
// ),
// ),
// SizedBox(
// height: 64,
// width: 68,
// child: TextFormField(
// onSaved: (pin4){},
// textAlign: TextAlign.center,
// textDirection: TextDirection.ltr,
// decoration: InputDecoration(
// hintText: '0',
// contentPadding: const EdgeInsets.all(18),
// enabledBorder: OutlineInputBorder(
// borderSide: const BorderSide(
// color: Colors.white60,
// width: 1,
// ),
// borderRadius: BorderRadius.circular(10)),
// focusedBorder: OutlineInputBorder(
// borderSide:   BorderSide(
// color: kAccentColor,
// width: 2,
// ),
// borderRadius: BorderRadius.circular(15))),
// style: Theme.of(context).textTheme.headline6,
// keyboardType: TextInputType.number,
// inputFormatters: [
// LengthLimitingTextInputFormatter(1),
// FilteringTextInputFormatter.digitsOnly,
// ],
// ),
// ),