import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:rashno/Const/styles.dart';

class CustomTextField extends StatelessWidget {
  final VoidCallback? onTab;
  final String? hintText;
  final Icon? icon;
  final keyboardType;
  final TextEditingController controller;
  final Function(String)? onChanged;
  final Function(String)? validation;
  final bool atuoFocused;
  final int limitation;
  CustomTextField({
    Key? key,
    this.onTab,
    required this.validation,
    required this.hintText,
    this.icon,
    this.keyboardType,
    this.onChanged,
    required this.controller,
    required this.atuoFocused,
    required this.limitation,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: TextFormField(
        onTap: onTab,
        //  textDirection: TextDirection.rtl ,
        autofocus: atuoFocused,
        textAlign: TextAlign.right,
        // onChanged: onChanged,
        controller: controller,
        keyboardType: keyboardType,
        validator: (value) => validation!(value!),
        inputFormatters: [LengthLimitingTextInputFormatter(limitation)],
        textDirection: TextDirection.rtl,
        decoration: InputDecoration(

            //----------------------------------------------------------------
            
            labelText: hintText,
            floatingLabelBehavior: FloatingLabelBehavior.auto,
            labelStyle: Theme.of(context).textTheme.bodyMedium,
            floatingLabelStyle: Theme.of(context).textTheme.headlineSmall,
            alignLabelWithHint: false,
            hintStyle: TextStyle(color: Colors.grey),
            hintTextDirection: TextDirection.rtl,
            floatingLabelAlignment: FloatingLabelAlignment.center

            //--------------------------------------------------------------

            ),
      ),
    );
  }
}
