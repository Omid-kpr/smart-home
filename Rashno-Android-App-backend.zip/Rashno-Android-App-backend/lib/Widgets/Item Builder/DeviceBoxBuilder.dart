import 'package:flutter/material.dart';
import '../../Functions And Providers/Classes/RoomAndDevice.dart';
import '../../Ui/App/HomePageFunctions/AddDevicePage.dart';
import '../Buttons/AddNewButton.dart';
import '../TestWidgets/TouchableBox.dart';

class DeviceBoxBuilder extends StatelessWidget {
    DeviceBoxBuilder({
    super.key, required this.roomList,
    required this.CurrentRoom ,
  });
  final List<Room>  roomList ;

  final int CurrentRoom ;
  @override
  Widget build(BuildContext context) {
    if (  roomList[CurrentRoom].devices.isNotEmpty) {

    return GridView.builder(
        physics: ScrollPhysics(),
        gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 200,
           crossAxisSpacing: 20,
 mainAxisSpacing: 0 ,

        ),
        itemCount: roomList[CurrentRoom].devices.length,
        shrinkWrap: true,
        itemBuilder: (context, index) {
          int _currentIndex = index ;
            return TouchableBox(
              currentIndex: _currentIndex,
              currentRoom: CurrentRoom,
              width: 160,
              height: 170,
              borderRadius: 15,
              icon:  roomList[CurrentRoom].devices[index].icon   ,
              text: roomList[CurrentRoom].devices[index].name,
              powerOnOff: roomList[CurrentRoom].devices[index].onOff,
            );




        });
    }
    else{return  Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: AddNewButton( text : 'اضافه کردن دستگاه جدید به این اتاق' ,  icon : Icons.add_circle     ,  onTab: (){  Navigator.pushNamed(context, AddDevicePage.routName);}),
    ) ;  }
  }
}

