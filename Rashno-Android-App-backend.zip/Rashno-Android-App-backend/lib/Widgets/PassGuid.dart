import 'package:flutter/material.dart';

import '../utils/constants/colors.dart';

class PassGuid extends StatefulWidget {
  PassGuid({super.key , required this.isValidChar, required this.isEight});

  final bool isValidChar ;
  final bool isEight ;
  @override
  State<PassGuid> createState() => _PassGuidState();
}

class _PassGuidState extends State<PassGuid> {


  @override
  Widget build(BuildContext context) {

    return  Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Row(
              children: [
                Text(' ترکیبی از عدد و حروف انگلیسی',
                    style: widget.isValidChar
                        ? Theme.of(context)
                        .textTheme
                        .bodyLarge
                        ?.copyWith(color: TColors.success)
                        : Theme.of(context)
                        .textTheme
                        .bodyLarge
                        ?.copyWith(color: TColors.secondary)),
                SizedBox(
                  width: 4,
                ),
                Icon(
                  widget.isValidChar ? Icons.check_box : Icons.error,
                  color: widget.isValidChar ? TColors.success : TColors.secondary,
                ),
              ],
            ),
            SizedBox(height: 4,) ,
            Row(
              children: [
                Text(' حداقل هشت کاراکتر ',
                    style: widget.isEight
                        ? Theme.of(context)
                        .textTheme
                        .bodyLarge
                        ?.copyWith(color: TColors.success)
                        : Theme.of(context)
                        .textTheme
                        .bodyLarge
                        ?.copyWith(color: TColors.secondary)),
                SizedBox(width: 4,) ,
                Icon(
                  widget.isEight ? Icons.check_box : Icons.error,
                  color: widget.isEight ? TColors.success : TColors.secondary,
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }
}