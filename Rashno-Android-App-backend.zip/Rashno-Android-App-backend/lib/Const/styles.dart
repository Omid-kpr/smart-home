import 'package:flutter/material.dart';


// Color kAccentColor = Color(0xFF004a77) ;
Color kAccentColor = Color(0xFF4851ec) ;

// Color kOnAccentColor = Color(0xff81c0ec) ;
Color kOnAccentColor = Color(0xffffffff) ;

Color kFocusColor = Color(0xff2d7699) ;
Color kBackgroundColor_Dark = Color(0xFF17171A) ;
Color kBackgroundColor_Light = Color(0xFFE2E2EA) ;
Color kCardColor = Color(0xff1f1737) ;
Color kErrorColor = Colors.redAccent  ;
Color kLighterBackgroundColor = Color(0xff1f282f) ;

Color kOnColor = Color(0xFF4b68ff)  ;
Color kOffColor = Color(0xff211f37) ;
Color kaddIcon = Color(0xFF4D557A) ;

//19191A


double kBorderRadius_Box=12.0  ;



TextStyle kErrorTextfield =TextStyle(color: Colors.redAccent   , fontSize: 16  , fontFamily: 'yekan' , )  ;
TextStyle kHintTextField =TextStyle(     fontSize: 16 , fontFamily: 'yekan')  ;


TextStyle kOnButtonText =TextStyle(color: kOnAccentColor , fontSize: 18, fontWeight: FontWeight.bold , fontFamily: 'yekan')  ;
//small text:
TextStyle kSmall_W200_Text =TextStyle(      fontSize: 16 , fontWeight: FontWeight.w200, fontFamily: 'yekan')  ;

TextStyle kBigTitle =TextStyle(   fontSize: 28 , fontWeight: FontWeight.bold , fontFamily: 'yekan')  ;
TextStyle kBigTitleAccentColor =TextStyle(  fontSize: 28 , fontWeight: FontWeight.bold , fontFamily: 'yekan')  ;
TextStyle kSmallText =TextStyle(      fontSize: 14 , fontWeight: FontWeight.w200, fontFamily: 'yekan')  ;
TextStyle kMText =TextStyle(     fontSize: 18 , fontWeight: FontWeight.w400, fontFamily: 'yekan')  ;
TextStyle kMBoldText =TextStyle(    fontSize: 24 , fontWeight: FontWeight.w700, fontFamily: 'yekan')  ;

TextStyle kDeviceNameText =TextStyle(    fontSize: 16 , fontWeight: FontWeight.w400, fontFamily: 'yekan')  ;


double kSize_15 = 15.0 ;
double kSize_30 = 30.0 ;
double kSize_24 =24.0 ;
double kBorderRadius = 12 ;
Color kWhite = Colors.white ;


