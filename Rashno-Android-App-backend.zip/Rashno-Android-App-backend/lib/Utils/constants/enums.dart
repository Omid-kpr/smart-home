
enum TextSizes { small, medium, large }



