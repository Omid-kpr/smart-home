import 'package:flutter/material.dart';

import '../../constants/colors.dart';
import '../../constants/sizes.dart';



class TBottomAppBar{
  TBottomAppBar._();

  static const lightButtonNavTheme =  BottomAppBar(

    elevation: 0,

    surfaceTintColor: Colors.transparent,

  );
  static const darkButtonNavTheme = BottomAppBar(
    elevation: 0,

    surfaceTintColor: Colors.transparent,

  );
}