import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/web_socket_channel.dart';


// * server handling codes *
final channel = WebSocketChannel.connect(Uri.parse('ws://10.0.2.2:4050'));
bool message_handeled = false;
// final channel = WebSocketChannel.connect(Uri.parse('ws://localhost:4050'));

// Handles incoming messages from the WebSocket connection.
Future<void> handleIncomingMessages() async {
  channel.stream.listen((dynamic message) async {
    print("server message is: $message");
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var parse = jsonDecode(message);
    switch (parse["status"]) {
      case 0:
        print("token is: ${parse["token"]} ");
        await prefs.setString('token', parse["token"]);
        message_handeled = true;
        break;
      case 1:
        print("wrong password");
        message_handeled = true;
        break;
      case 2:
        print("wrong user");
        message_handeled = true;
        break;
      default:
        print("unknown message");
        message_handeled = true;
    }
  });
}

/// Closes the WebSocket connection by closing the sink.
void closeWebSocket() {
  channel.sink.close();
}

void _sendMessage(String route, Map<String, dynamic> data) {
  final message = {'route': route, 'data': data};
  channel.sink.add(jsonEncode(message));
}

/// Sends a login request with email and password to the
/// WebSocket server at the /login route.
Future<void> login(email, password) async {
  message_handeled = false;
  _sendMessage('/login', {'email': email, 'password': password});
  handleIncomingMessages();
}

/// Sends a signup request with email and password to the
/// WebSocket server at the /signup route.
Future<void> signup(email, password) async {
  message_handeled = false;
  _sendMessage('/signup', {'email': email, 'password': password});
  handleIncomingMessages();
}



